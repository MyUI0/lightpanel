package handlers

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"lightpanel/config"
	"lightpanel/models"
)

var (
	downloadTasks  sync.Map
	downloadHistMu sync.Mutex
	storeCache     struct {
		apps     []models.StoreApp
		err      string
		errType  string
		lastInit time.Time
	}
	storeCacheLock sync.Mutex
	storeCacheTTL  = 5 * time.Minute
)

func getSystemArch() string {
	arch := runtime.GOARCH
	switch arch {
	case "x86_64":
		return "amd64"
	case "aarch64":
		return "arm64"
	case "armv7l":
		return "armv7"
	case "i386", "i686":
		return "386"
	default:
		return arch
	}
}

func getSystemOS() string {
	os := runtime.GOOS
	switch os {
	case "darwin":
		return "darwin"
	default:
		return "linux"
	}
}

func getCachedSystemInfo() config.SystemInfo {
	var sysInfo config.SystemInfo
	if err := LoadJSON(config.ConfigSys, &sysInfo); err == nil && sysInfo.Arch != "" {
		return sysInfo
	}
	
	arch := getSystemArch()
	os := getSystemOS()
	sysInfo = config.SystemInfo{Arch: arch, OS: os}
	_ = WriteJSON(config.ConfigSys, sysInfo)
	return sysInfo
}

func replaceURLParams(url string) (string, error) {
	sysInfo := getCachedSystemInfo()
	arch := sysInfo.Arch
	os := sysInfo.OS
	
	client := &http.Client{Timeout: 10 * time.Second}
	
	currentURL := strings.ReplaceAll(url, "{{arch}}", arch)
	currentURL = strings.ReplaceAll(currentURL, "{{os}}", os)
	
	if currentURL != url {
		resp, err := client.Head(currentURL)
		if err == nil {
			defer resp.Body.Close()
			if resp.StatusCode == 200 {
				return currentURL, nil
			}
		}
	}
	
	if strings.Contains(url, "{{arch}}") || strings.Contains(url, "{{os}}") {
		return "", fmt.Errorf("当前架构 %s 无可用下载链接", arch)
	}
	return url, nil
}

func testURL(url string) bool {
	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Head(url)
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	return resp.StatusCode == 200
}

func init() {
	go func() {
		time.Sleep(2 * time.Second)
		var srcs []models.StoreSource
		LoadJSON(config.ConfigSrc, &srcs)
		initStoreCache(srcs, 0)
	}()

	ticker := time.NewTicker(10 * time.Minute)
	go func() {
		defer func() { recover() }()
		defer ticker.Stop()
		for range ticker.C {
			downloadTasks.Range(func(key, value any) bool {
				if t, ok := value.(*models.DownloadTask); ok {
					status := t.GetStatus()
					if status == "completed" || status == "error" {
						if time.Since(t.Last) > 30*time.Minute {
							downloadTasks.Delete(key)
						}
					} else if status == "downloading" && time.Since(t.Last) > 60*time.Minute {
						t.SetStatus("error")
						downloadTasks.Delete(key)
					}
				}
				return true
			})
		}
	}()
}

func initStoreCache(srcs []models.StoreSource, srcIdx int) {
	if len(srcs) == 0 {
		storeCache.apps = nil
		storeCache.err = "没有可用的商店源"
		storeCache.errType = "none"
		storeCache.lastInit = time.Now()
		return
	}

	client := &http.Client{Timeout: 10 * time.Second}
	if srcIdx < 0 || srcIdx >= len(srcs) {
		srcIdx = 0
	}
	resp, err := client.Get(srcs[srcIdx].URL)
	if err != nil {
		storeCache.apps = nil
		storeCache.err = "无法连接到商店源"
		storeCache.errType = "network"
		storeCache.lastInit = time.Now()
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		storeCache.apps = nil
		storeCache.err = fmt.Sprintf("商店源返回错误: %d", resp.StatusCode)
		storeCache.errType = "http"
		storeCache.lastInit = time.Now()
		return
	}

	var apps []models.StoreApp
	limitedReader := io.LimitReader(resp.Body, maxStoreResponseSize)
	if err := json.NewDecoder(limitedReader).Decode(&apps); err != nil {
		storeCache.apps = nil
		storeCache.err = "商店数据格式错误"
		storeCache.errType = "parse"
		storeCache.lastInit = time.Now()
		return
	}

	storeCache.apps = apps
	storeCache.err = ""
	storeCache.errType = ""
	storeCache.lastInit = time.Now()
}

func getStoreApps(srcs []models.StoreSource, srcIdx int) ([]models.StoreApp, string, string) {
	storeCacheLock.Lock()
	defer storeCacheLock.Unlock()

	if time.Since(storeCache.lastInit) > storeCacheTTL {
		initStoreCache(srcs, srcIdx)
	}

	return storeCache.apps, storeCache.err, storeCache.errType
}

func refreshStoreCache() {
	storeCacheLock.Lock()
	defer storeCacheLock.Unlock()
	var srcs []models.StoreSource
	LoadJSON(config.ConfigSrc, &srcs)
	initStoreCache(srcs, 0)
}

func loadDownloadHistory() []models.DownloadHistory {
	var history []models.DownloadHistory
	if err := LoadJSON(config.ConfigDl, &history); err != nil {
		return nil
	}
	return history
}

func saveDownloadHistory(history []models.DownloadHistory) {
	if len(history) > config.MaxDownloadHistory {
		history = history[:config.MaxDownloadHistory]
	}
	_ = WriteJSON(config.ConfigDl, history)
}

func addDownloadRecord(task *models.DownloadTask, installed bool) {
	downloadHistMu.Lock()
	defer downloadHistMu.Unlock()
	
	history := loadDownloadHistory()
	record := models.DownloadHistory{
		ID:         task.ID,
		Name:       task.Name,
		URL:        task.URL,
		Cmd:        task.Cmd,
		Version:    task.Version,
		Status:     task.Status,
		Size:       task.Size,
		Downloaded: task.Downloaded,
		Progress:   task.Progress,
		Installed:  installed,
		Timestamp:  time.Now(),
	}
	
	updated := false
	for i := range history {
		if history[i].Name == task.Name {
			history[i] = record
			updated = true
			break
		}
	}
	
	if !updated {
		history = append([]models.DownloadHistory{record}, history...)
	}
	
	if len(history) > config.MaxDownloadHistory {
		history = history[:config.MaxDownloadHistory]
	}
	saveDownloadHistory(history)
}

func getDownloadTask(id string) (*models.DownloadTask, bool) {
	val, ok := downloadTasks.Load(id)
	if !ok {
		return nil, false
	}
	t, ok := val.(*models.DownloadTask)
	return t, ok
}

func snapshotTasks() []models.DownloadTask {
	var tasks []models.DownloadTask
	downloadTasks.Range(func(_, value any) bool {
		if t, ok := value.(*models.DownloadTask); ok {
			tasks = append(tasks, t.Snapshot())
		}
		return true
	})
	return tasks
}

func downloadPage(w http.ResponseWriter, r *http.Request) {
	tasks := snapshotTasks()
	history := loadDownloadHistory()
	
	downloadHistMu.Lock()
	defer downloadHistMu.Unlock()
	
	if len(history) > 0 {
		var apps map[string]models.Project
		_ = LoadJSON(config.ConfigApps, &apps)
		updated := false
		for i := range history {
			if history[i].Installed {
				if _, exists := apps[history[i].Name]; !exists {
					history[i].Installed = false
					updated = true
				}
			}
		}
		if updated {
			saveDownloadHistory(history)
		}
	}
	
	_ = htmlRender.ExecuteTemplate(w, "downloads", map[string]any{
		"Tasks":   tasks,
		"History": history,
	})
}

func apiDownloads(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	tasks := snapshotTasks()
	_ = json.NewEncoder(w).Encode(tasks)
}

func apiDownloadAction(w http.ResponseWriter, r *http.Request) {
	action := strings.TrimPrefix(r.URL.Path, "/dl/action/")
	parts := strings.SplitN(action, "/", 2)
	if len(parts) != 2 {
		w.WriteHeader(400)
		return
	}
	id, act := parts[0], parts[1]

	task, ok := getDownloadTask(id)
	if !ok {
		w.WriteHeader(404)
		return
	}

	switch act {
	case "pause":
		if task.GetStatus() == "downloading" {
			task.SetStatus("paused")
		}
	case "resume":
		if task.GetStatus() == "paused" {
			task.SetStatus("downloading")
			go resumeDownload(id)
		}
	case "delete":
		downloadTasks.Delete(id)
		if s := task.GetStatus(); s == "downloading" || s == "paused" {
			fpath := filepath.Join(config.AppsDir, task.Name, filepath.Base(task.URL))
			_ = os.Remove(fpath)
		}
	case "install":
		if task.GetStatus() == "completed" {
			installDownloadedApp(id)
			downloadTasks.Delete(id)
		}
	}

	w.WriteHeader(200)
}

func resumeDownload(id string) {
	defer func() { recover() }()
	task, ok := getDownloadTask(id)
	if !ok {
		return
	}

	sandbox := filepath.Join(config.AppsDir, task.Name)
	fname := filepath.Base(task.URL)
	if fname == "" || fname == "." || fname == "/" {
		fname = "download"
	}
	fpath := filepath.Join(sandbox, fname)

	var startOffset int64
	if info, err := os.Stat(fpath); err == nil {
		startOffset = info.Size()
	}

	client := &http.Client{Timeout: 60 * time.Second}
	req, err := http.NewRequest("GET", task.URL, nil)
	if err != nil {
		task.SetStatus("error")
		task.Last = time.Now()
		return
	}
	if startOffset > 0 {
		req.Header.Set("Range", "bytes="+strconv.FormatInt(startOffset, 10)+"-")
	}
	resp, e := client.Do(req)
	if e != nil {
		task.SetStatus("error")
		task.Last = time.Now()
		return
	}
	defer resp.Body.Close()

	if startOffset > 0 && resp.StatusCode != http.StatusPartialContent {
		_ = os.Remove(fpath)
		startOffset = 0
		task.UpdateProgress(0, 0, 0)
	}

	f, err := os.OpenFile(fpath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		task.SetStatus("error")
		task.Last = time.Now()
		return
	}
	defer f.Close()

	if startOffset == 0 {
		task.UpdateSize(resp.ContentLength)
		task.UpdateProgress(0, 0, 0)
	} else {
		task.UpdateProgress(startOffset, task.GetSize(), 0)
	}

	buf := make([]byte, 32*1024)
	for task.IsDownloading() {
		n, readErr := resp.Body.Read(buf)
		if n > 0 {
			if _, err := f.Write(buf[:n]); err != nil {
				task.SetStatus("error")
				task.Last = time.Now()
				break
			}
			downloaded := task.GetDownloaded() + int64(n)
			size := task.GetSize()
			var prog int
			if size > 0 {
				prog = int(float64(downloaded) / float64(size) * 100)
			}
			task.UpdateProgress(downloaded, size, prog)
		}
		if readErr != nil {
			if !errors.Is(readErr, io.EOF) {
				task.SetStatus("error")
				task.Last = time.Now()
			}
			break
		}
	}

	if task.GetStatus() == "downloading" {
		task.SetStatus("completed")
		task.UpdateProgress(task.GetDownloaded(), task.GetSize(), 100)
	}
}

func installDownloadedApp(id string) {
	task, ok := getDownloadTask(id)
	if !ok {
		return
	}

	appOpMu.Lock()
	defer appOpMu.Unlock()

	sandbox := filepath.Join(config.AppsDir, task.Name)
	fname := filepath.Base(task.URL)
	fpath := filepath.Join(sandbox, fname)

	if extractArchive(fpath, sandbox) {
		_ = os.Remove(fpath)
	} else if strings.HasSuffix(fname, ".sh") {
		_ = os.Chmod(fpath, 0755)
	}

	scanTime := time.Now().Add(-20 * time.Second)
	result := combinedDetect(sandbox, scanTime)

	var apps map[string]models.Project
	_ = LoadJSON(config.ConfigApps, &apps)
	apps[task.Name] = models.Project{
		Path:      sandbox,
		Cmd:       task.Cmd,
		SetupCmd:  task.SetupCmd,
		WorkDir:   result.WorkDir,
		Created:   time.Now().Format("2006-01-02 15:04"),
	}
	_ = WriteJSON(config.ConfigApps, apps)
	_ = os.WriteFile(filepath.Join(sandbox, "install_note.txt"), []byte(result.Note), 0644)
}

const maxStoreResponseSize = 10 * 1024 * 1024 // 10MB

func startStoreInstall(w http.ResponseWriter, r *http.Request) {
	idx, _ := strconv.Atoi(strings.TrimPrefix(r.URL.Path, "/install/"))
	srcIdx, _ := strconv.Atoi(r.URL.Query().Get("source"))
	var srcs []models.StoreSource
	_ = LoadJSON(config.ConfigSrc, &srcs)
	if srcIdx < 0 || srcIdx >= len(srcs) || idx < 0 {
		http.Redirect(w, r, "/store", 302)
		return
	}

	client := &http.Client{Timeout: 10 * time.Second}
	resp, e := client.Get(srcs[srcIdx].URL)
	if e != nil {
		http.Redirect(w, r, "/store", 302)
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		http.Redirect(w, r, "/store", 302)
		return
	}

	var apps []models.StoreApp
	limitedReader := io.LimitReader(resp.Body, maxStoreResponseSize)
	if err := json.NewDecoder(limitedReader).Decode(&apps); err != nil {
		http.Redirect(w, r, "/store", 302)
		return
	}
	if idx >= len(apps) {
		http.Redirect(w, r, "/store", 302)
		return
	}
	app := apps[idx]
	name := strings.TrimSpace(app.Name)
	if name == "" || strings.ContainsAny(name, `./\ `) || strings.HasPrefix(name, ".") || strings.Contains(name, "..") || strings.ContainsAny(name, ";&|'?*:#") {
		http.Redirect(w, r, "/store", 302)
		return
	}

	if app.URL == "" {
		appOpMu.Lock()
		var list map[string]models.Project
		_ = LoadJSON(config.ConfigApps, &list)
		if _, exists := list[name]; !exists {
			sandbox := filepath.Join(config.AppsDir, name)
			_ = os.MkdirAll(sandbox, 0755)

			scanTime := time.Now().Add(-20 * time.Second)
			result := combinedDetect(sandbox, scanTime)

			list[name] = models.Project{
				Path:      sandbox,
				Cmd:       app.Cmd,
				WorkDir:   result.WorkDir,
				Version:   app.Version,
				Created:   time.Now().Format("2006-01-02 15:04"),
			}
			_ = WriteJSON(config.ConfigApps, list)
			_ = os.WriteFile(filepath.Join(sandbox, "install_note.txt"), []byte(result.Note), 0644)
		}
		appOpMu.Unlock()
		http.Redirect(w, r, "/", 302)
		return
	}

	if !strings.HasPrefix(app.URL, "http://") && !strings.HasPrefix(app.URL, "https://") {
		http.Redirect(w, r, "/store", 302)
		return
	}
	if isPrivateURL(app.URL) {
		http.Redirect(w, r, "/store", 302)
		return
	}

	if app.AskParams {
		http.Redirect(w, r, "/store/params/"+strconv.Itoa(idx)+"?source="+strconv.Itoa(srcIdx), 302)
		return
	}

	dlURL, urlErr := replaceURLParams(app.URL)
	if urlErr != nil || (dlURL == app.URL && strings.Contains(app.URL, "{{arch}}")) {
		http.Redirect(w, r, "/store?err=no_arch", 302)
		return
	}
	dlName := name
	dlCmd := app.Cmd
	dlVersion := app.Version
	dlSetupCmd := app.SetupCmd
	dlAutoExtract := app.AutoExtract
	dlMakeExec := app.MakeExec
	id := "dl_" + strconv.FormatInt(time.Now().UnixNano(), 36)
	task := &models.DownloadTask{
		ID:       id,
		Name:     dlName,
		URL:      dlURL,
		Cmd:      dlCmd,
		Size:     0,
		Status:   "downloading",
		Last:     time.Now(),
		Version:  dlVersion,
		SetupCmd: dlSetupCmd,
	}
	downloadTasks.Store(id, task)

	go func() {
		defer func() { recover() }()
		sandbox := filepath.Join(config.AppsDir, dlName)
		_ = os.MkdirAll(sandbox, 0755)

		fname := filepath.Base(dlURL)
		if fname == "" || fname == "." || fname == "/" {
			fname = "download"
		}
		fpath := filepath.Join(sandbox, fname)

		dlClient := &http.Client{Timeout: 60 * time.Second}
		dlResp, e := dlClient.Get(dlURL)
		if e != nil {
			task.SetStatus("error")
			task.Last = time.Now()
			return
		}
		defer dlResp.Body.Close()

		task.UpdateSize(dlResp.ContentLength)

		f, err := os.Create(fpath)
		if err != nil {
			task.SetStatus("error")
			return
		}

		buf := make([]byte, 32*1024)
		for task.IsDownloading() {
			n, readErr := dlResp.Body.Read(buf)
			if n > 0 {
				if _, err := f.Write(buf[:n]); err != nil {
					task.SetStatus("error")
					task.Last = time.Now()
					break
				}
				downloaded := task.GetDownloaded() + int64(n)
				size := task.GetSize()
				var prog int
				if size > 0 {
					prog = int(float64(downloaded) / float64(size) * 100)
				}
				task.UpdateProgress(downloaded, size, prog)
			}
			if readErr != nil {
				if !errors.Is(readErr, io.EOF) {
					task.SetStatus("error")
					task.Last = time.Now()
				}
				break
			}
		}
		_ = f.Close()

		if task.GetStatus() == "downloading" {
			task.SetStatus("completed")
			task.UpdateProgress(task.GetDownloaded(), task.GetSize(), 100)
			extracted := false
			if dlAutoExtract {
				extracted = extractArchive(fpath, sandbox)
				if extracted {
					_ = os.Remove(fpath)
				}
			}
			if !extracted && dlMakeExec && strings.HasSuffix(fname, ".sh") {
				_ = os.Chmod(fpath, 0755)
			}

			time.Sleep(15 * time.Second)
			scanTime := time.Now().Add(-20 * time.Second)
			result := combinedDetect(sandbox, scanTime)
			appOpMu.Lock()
			var updated map[string]models.Project
			if err := LoadJSON(config.ConfigApps, &updated); err == nil {
				proj, exists := updated[dlName]
				if !exists {
					proj = models.Project{
						Path:      sandbox,
						Created:   time.Now().Format("2006-01-02 15:04"),
					}
				}
				if result.WorkDir != "" {
					proj.WorkDir = result.WorkDir
				}
				if result.Binary != "" {
					proj.Cmd = result.Binary
				} else if dlCmd != "" {
					proj.Cmd = dlCmd
				}
				proj.Version = dlVersion
				updated[dlName] = proj
				_ = WriteJSON(config.ConfigApps, updated)
			}
			appOpMu.Unlock()
			_ = os.WriteFile(filepath.Join(sandbox, "install_note.txt"), []byte(result.Note), 0644)

			addDownloadRecord(task, true)
		}
	}()

	http.Redirect(w, r, "/downloads", 302)
}

func storePage(w http.ResponseWriter, r *http.Request) {
	var srcs []models.StoreSource
	_ = LoadJSON(config.ConfigSrc, &srcs)
	idx, _ := strconv.Atoi(r.URL.Query().Get("source"))
	if idx < 0 || idx >= len(srcs) {
		idx = 0
	}

	apps, storeErr, storeErrType := getStoreApps(srcs, idx)
	
	if errMsg := r.URL.Query().Get("err"); errMsg == "no_arch" {
		sysInfo := getCachedSystemInfo()
		storeErr = fmt.Sprintf("当前系统架构(%s)无可用下载链接，请检查官方文档", sysInfo.Arch)
		storeErrType = "arch"
	}

	if len(apps) == 0 {
		if storeErr == "" {
			storeErr = "没有可用的应用"
		}
		apps = []models.StoreApp{{
			Name:   "获取失败",
			Desc:   storeErr,
			Icon:   "",
			Author: "system",
		}}
	}
	var deployed map[string]bool
	if config.ConfigApps != "" {
		var deployedApps map[string]models.Project
		if err := LoadJSON(config.ConfigApps, &deployedApps); err == nil {
			deployed = make(map[string]bool)
			for name := range deployedApps {
				deployed[name] = true
			}
		}
	}

	_ = htmlRender.ExecuteTemplate(w, "store", map[string]any{
		"Apps":         apps,
		"Sources":      srcs,
		"Active":       idx,
		"StoreErr":     storeErr,
		"StoreErrType": storeErrType,
		"Deployed":     deployed,
	})
}

func checkAppUpdates(apps map[string]models.Project) map[string]string {
	updates := make(map[string]string)

	var srcs []models.StoreSource
	if err := LoadJSON(config.ConfigSrc, &srcs); err != nil || len(srcs) == 0 {
		return updates
	}

	type storeAppInfo struct {
		name        string
		version     string
		url         string
		autoExtract bool
		makeExec    bool
	}

	appChan := make(chan storeAppInfo, len(srcs)*10)
	var wg sync.WaitGroup

	for _, src := range srcs {
		wg.Add(1)
		go func(srcURL string) {
			defer wg.Done()
			client := &http.Client{Timeout: 5 * time.Second}
			resp, err := client.Get(srcURL)
			if err != nil {
				return
			}
			defer resp.Body.Close()
			if resp.StatusCode != 200 {
				return
			}
			var storeApps []models.StoreApp
			if err := json.NewDecoder(io.LimitReader(resp.Body, maxStoreResponseSize)).Decode(&storeApps); err != nil {
				return
			}
			for _, app := range storeApps {
				if app.Version != "" {
					appChan <- storeAppInfo{name: app.Name, version: app.Version, url: srcURL}
				}
			}
		}(src.URL)
	}

	go func() {
		wg.Wait()
		close(appChan)
	}()

	storeAppsByName := make(map[string]map[string]string)
	for info := range appChan {
		if storeAppsByName[info.name] == nil {
			storeAppsByName[info.name] = make(map[string]string)
		}
		storeAppsByName[info.name][info.url] = info.version
	}

	for name, app := range apps {
		if app.SourceURL == "" || app.Version == "" {
			continue
		}
		if storeVersions, ok := storeAppsByName[name]; ok {
			if newVer, ok := storeVersions[app.SourceURL]; ok {
				if newVer != app.Version {
					updates[name] = newVer
				}
			}
		}
	}

	return updates
}

func storeParamsPage(w http.ResponseWriter, r *http.Request) {
	path := strings.TrimPrefix(r.URL.Path, "/install/params/")
	idx, _ := strconv.Atoi(strings.TrimSuffix(path, "/"))
	srcIdx, _ := strconv.Atoi(r.URL.Query().Get("source"))

	var srcs []models.StoreSource
	_ = LoadJSON(config.ConfigSrc, &srcs)
	if srcIdx < 0 || srcIdx >= len(srcs) || idx < 0 {
		http.Redirect(w, r, "/store", 302)
		return
	}

	apps, _, _ := getStoreApps(srcs, srcIdx)
	if idx >= len(apps) {
		http.Redirect(w, r, "/store", 302)
		return
	}

	app := apps[idx]
	dlURL, _ := replaceURLParams(app.URL)

	_ = htmlRender.ExecuteTemplate(w, "store_params", map[string]any{
		"App":        app,
		"Index":      idx,
		"SrcIdx":     srcIdx,
		"TestedURL":  dlURL,
	})
}

func confirmInstallWithParams(w http.ResponseWriter, r *http.Request) {
	path := strings.TrimPrefix(r.URL.Path, "/install/confirm/")
	idx, _ := strconv.Atoi(strings.TrimSuffix(path, "/"))
	srcIdx, _ := strconv.Atoi(r.URL.Query().Get("source"))
	userParams := strings.TrimSpace(r.FormValue("user_params"))

	var srcs []models.StoreSource
	_ = LoadJSON(config.ConfigSrc, &srcs)
	if srcIdx < 0 || srcIdx >= len(srcs) || idx < 0 {
		http.Redirect(w, r, "/store", 302)
		return
	}

	apps, _, _ := getStoreApps(srcs, srcIdx)
	if idx >= len(apps) {
		http.Redirect(w, r, "/store", 302)
		return
	}

	app := apps[idx]
	name := strings.TrimSpace(app.Name)
	if name == "" {
		http.Redirect(w, r, "/store", 302)
		return
	}

	dlURL, urlErr := replaceURLParams(app.URL)
	if urlErr != nil || (dlURL == app.URL && strings.Contains(app.URL, "{{arch}}")) {
		http.Redirect(w, r, "/store?err=no_arch", 302)
		return
	}

	dlName := name
	dlCmd := app.Cmd
	if userParams != "" {
		dlCmd = strings.ReplaceAll(dlCmd, "{{params}}", userParams)
		dlCmd = dlCmd + " " + userParams
	}
	dlVersion := app.Version
	dlSetupCmd := app.SetupCmd
	dlWorkDir := app.WorkDir
	id := "dl_" + strconv.FormatInt(time.Now().UnixNano(), 36)
	task := &models.DownloadTask{
		ID:       id,
		Name:     dlName,
		URL:      dlURL,
		Cmd:      dlCmd,
		Size:     0,
		Status:   "downloading",
		Last:     time.Now(),
		Version:  dlVersion,
		SetupCmd: dlSetupCmd,
		WorkDir:  dlWorkDir,
	}
	downloadTasks.Store(id, task)

	http.Redirect(w, r, "/downloads", 302)
}

func apiCheckUpdates(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	var apps map[string]models.Project
	_ = LoadJSON(config.ConfigApps, &apps)

	updates := checkAppUpdates(apps)
	json.NewEncoder(w).Encode(updates)
}
