package handlers

import (
	"fmt"
	"html/template"
	"strings"
	"sync"
	"time"
)

var (
	htmlRender *template.Template
	renderOnce sync.Once
)

func InitTemplates() {
	renderOnce.Do(func() {
		funcMap := template.FuncMap{
			"tolower":    strings.ToLower,
			"escape":     template.HTMLEscapeString,
			"formatSize": formatSize,
			"formatTime": func(t time.Time) string { return t.Format("2006-01-02 15:04") },
			"getBgUrl":   getBgURL,
			"getLogoUrl": getLogoURL,
		}

		tmpl := template.New("").Funcs(funcMap)
		tmpl = template.Must(tmpl.Parse(
			htmlLogin + "\n" +
				htmlIndex + "\n" +
				htmlStore + "\n" +
				htmlStoreParams + "\n" +
				htmlDownloads + "\n" +
				htmlEdit + "\n" +
				htmlSource + "\n" +
				htmlSetting + "\n" +
				htmlSystem + "\n" +
				htmlLog + "\n" +
				htmlScriptAnalyze,
		))

		htmlRender = tmpl
	})
}

func formatSize(b int64) string {
	if b <= 0 {
		return "0 B"
	}
	units := []string{"B", "KB", "MB", "GB", "TB"}
	i := 0
	for b >= 1024 && i < len(units)-1 {
		b /= 1024
		i++
	}
	return fmt.Sprintf("%.1f %s", float64(b), units[i])
}
