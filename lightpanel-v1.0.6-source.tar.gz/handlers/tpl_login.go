package handlers

var htmlLogin = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>登录 - LightPanel</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Inter',system-ui,sans-serif}
body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0f0f23;position:relative;overflow:hidden}
body::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 30% 50%,rgba(99,102,241,0.15),transparent 60%),radial-gradient(ellipse at 70% 50%,rgba(168,85,247,0.1),transparent 50%)}
.card{position:relative;z-index:1;background:rgba(255,255,255,0.04);backdrop-filter:blur(30px);border:1px solid rgba(255,255,255,0.08);border-radius:20px;padding:2.5rem;width:360px}
.logo{width:48px;height:48px;background:linear-gradient(135deg,#6366f1,#a855f7);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1.2rem;box-shadow:0 0 15px rgba(99,102,241,0.4);border:2px solid rgba(255,255,255,0.2)}
.logo i{color:#fff;font-size:1.3rem}
h1{text-align:center;font-size:1.3rem;font-weight:700;color:#fff;margin-bottom:0.3rem}
.sub{text-align:center;font-size:0.8rem;color:rgba(255,255,255,0.4);margin-bottom:1.8rem}
.field{margin-bottom:0.8rem}
.field label{display:block;font-size:0.75rem;font-weight:600;color:rgba(255,255,255,0.5);margin-bottom:0.3rem}
.field input{width:100%;padding:0.65rem 0.85rem;border-radius:10px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.05);color:#fff;font-size:0.85rem;outline:none;transition:all 0.2s}
.field input:focus{border-color:#6366f1;box-shadow:0 0 0 3px rgba(99,102,241,0.15)}
.btn{width:100%;padding:0.75rem;border-radius:10px;border:none;background:linear-gradient(135deg,#6366f1,#7c3aed);color:#fff;font-size:0.9rem;font-weight:600;cursor:pointer;transition:all 0.2s;margin-top:0.5rem}
.btn:hover{box-shadow:0 6px 20px rgba(99,102,241,0.35)}
.btn:disabled{opacity:0.5;cursor:not-allowed}
.err{background:rgba(239,68,68,0.1);color:#f87171;padding:0.6rem 0.8rem;border-radius:8px;font-size:0.78rem;margin-bottom:0.8rem;text-align:center;border:1px solid rgba(239,68,68,0.2)}
.warn{background:rgba(245,158,11,0.1);color:#fbbf24;padding:0.6rem 0.8rem;border-radius:8px;font-size:0.78rem;margin-bottom:0.8rem;text-align:center;border:1px solid rgba(245,158,11,0.2)}
.ft{text-align:center;font-size:0.65rem;color:rgba(255,255,255,0.25);margin-top:1.2rem}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
<div class="card">
  <div class="logo"><i class="fa-solid fa-server"></i></div>
  <h1>LightPanel</h1>
  <p class="sub">服务器管理面板</p>
  {{if eq .Err "1"}}
  <div class="err"><i class="fa-solid fa-circle-exclamation" style="margin-right:0.3rem;"></i>用户名或密码错误</div>
  {{end}}
  {{if eq .Err "locked"}}
  <div class="err"><i class="fa-solid fa-lock" style="margin-right:0.3rem;"></i>登录失败次数过多，请等待 <span id="lockTimer">{{.LockTime}}</span> 秒后重试</div>
  {{end}}
  <form action="/login/auth" method="post" onsubmit="var b=document.getElementById('loginBtn');if(b&&b.disabled){event.preventDefault();return false}">
    <div class="field"><label>用户名</label><input name="username" placeholder="请输入用户名" required autocomplete="username"></div>
    <div class="field"><label>密码</label><input name="password" type="password" placeholder="请输入密码" required autocomplete="current-password"></div>
    <button class="btn" type="submit" id="loginBtn"><i class="fa-solid fa-right-to-bracket" style="margin-right:0.4rem;"></i>登录</button>
  </form>
  <div class="ft">LightPanel · 轻量高效</div>
</div>
{{if eq .Err "locked"}}
<script>
(function(){
var el=document.getElementById('lockTimer');
var btn=document.getElementById('loginBtn');
if(!el||!btn)return;
var s=parseInt(el.textContent)||0;
btn.disabled=true;
var t=setInterval(function(){
s--;
if(s<=0){clearInterval(t);btn.disabled=false;el.textContent='0';}
else{el.textContent=s;}
},1000);
})();
</script>
{{end}}
</body>
</html>`
