package handlers

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"lightpanel/config"
	"lightpanel/models"
)

var createTasks sync.Map

type CreateTask struct {
	ID        string
	Name      string
	Progress  int
	Status    string
	Message   string
	CreatedAt time.Time
}

func apiCreateProgress(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	taskID := strings.TrimPrefix(r.URL.Path, "/create/progress/")
	val, ok := createTasks.Load(taskID)
	if !ok {
		json.NewEncoder(w).Encode(map[string]any{"status": "not_found"})
		return
	}
	task := val.(*CreateTask)
	json.NewEncoder(w).Encode(task)
}

func createApp(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")

	name := strings.TrimSpace(r.FormValue("name"))
	down := strings.TrimSpace(r.FormValue("url"))
	cmd := strings.TrimSpace(r.FormValue("cmd"))
	setupCmd := strings.TrimSpace(r.FormValue("setup_cmd"))
	autoExtract := r.FormValue("auto_extract") == "on"
	makeExec := r.FormValue("make_exec") == "on"

	if name == "" {
		json.NewEncoder(w).Encode(map[string]any{"error": "应用名称不能为空"})
		return
	}
	if strings.ContainsAny(name, `/\`) || strings.ContainsAny(name, `;&|'`) || strings.HasPrefix(name, ".") || strings.Contains(name, "..") {
		json.NewEncoder(w).Encode(map[string]any{"error": "应用名称包含非法字符，仅允许字母数字"})
		return
	}

	appOpMu.Lock()
	var apps map[string]models.Project
	_ = LoadJSON(config.ConfigApps, &apps)
	if _, exists := apps[name]; exists {
		appOpMu.Unlock()
		json.NewEncoder(w).Encode(map[string]any{"error": "应用已存在"})
		return
	}
	appOpMu.Unlock()

	taskID := "create_" + strconv.FormatInt(time.Now().UnixNano(), 36)
	task := &CreateTask{
		ID:        taskID,
		Name:      name,
		Progress:  0,
		Status:    "creating",
		Message:   "准备创建...",
		CreatedAt: time.Now(),
	}
	createTasks.Store(taskID, task)

	go func() {
		defer func() { recover() }()
		sandbox := filepath.Join(config.AppsDir, name)
		if err := os.MkdirAll(sandbox, 0755); err != nil {
			task.Status = "error"
			task.Message = "创建目录失败"
			return
		}

		if down != "" {
			if !strings.HasPrefix(down, "http://") && !strings.HasPrefix(down, "https://") {
				task.Status = "error"
				task.Message = "URL 格式错误"
				_ = os.RemoveAll(sandbox)
				return
			}

			dlID := "dl_" + strconv.FormatInt(time.Now().UnixNano(), 36)
			dlTask := &models.DownloadTask{
				ID:     dlID,
				Name:   name,
				URL:    down,
				Cmd:    cmd,
				Status: "downloading",
				Last:   time.Now(),
			}
			downloadTasks.Store(dlID, dlTask)
			task.Message = "正在下载..."
			task.Progress = 10

			client := &http.Client{Timeout: 120 * time.Second}
			resp, e := client.Get(down)
			if e != nil {
				dlTask.SetStatus("error")
				dlTask.Last = time.Now()
				task.Status = "error"
				task.Message = "下载失败: " + e.Error()
				_ = os.RemoveAll(sandbox)
				return
			}
			defer resp.Body.Close()
			if resp.StatusCode != 200 {
				dlTask.SetStatus("error")
				dlTask.Last = time.Now()
				task.Status = "error"
				task.Message = "HTTP " + fmt.Sprint(resp.StatusCode)
				_ = os.RemoveAll(sandbox)
				return
			}

			dlTask.Size = resp.ContentLength
			fname := filepath.Base(down)
			if fname == "" || fname == "." || fname == "/" {
				fname = "download"
			}
			fpath := filepath.Join(sandbox, fname)
			f, err := os.Create(fpath)
			if err != nil {
				dlTask.SetStatus("error")
				dlTask.Last = time.Now()
				task.Status = "error"
				task.Message = "创建文件失败"
				_ = os.RemoveAll(sandbox)
				return
			}

			buf := make([]byte, 32*1024)
			var totalWritten int64
			for {
				n, readErr := resp.Body.Read(buf)
				if n > 0 {
					if _, writeErr := f.Write(buf[:n]); writeErr != nil {
						_ = f.Close()
						dlTask.SetStatus("error")
						dlTask.Last = time.Now()
						task.Status = "error"
						task.Message = "写入失败"
						_ = os.Remove(fpath)
						_ = os.RemoveAll(sandbox)
						return
					}
					totalWritten += int64(n)
					if dlTask.Size > 0 {
						dlTask.Downloaded = totalWritten
						dlTask.Progress = int(float64(totalWritten) / float64(dlTask.Size) * 90)
						task.Progress = 10 + dlTask.Progress/10
					}
				}
				if readErr != nil {
					if !errors.Is(readErr, io.EOF) {
						_ = f.Close()
						dlTask.SetStatus("error")
						dlTask.Last = time.Now()
						task.Status = "error"
						task.Message = "读取失败"
						_ = os.Remove(fpath)
						_ = os.RemoveAll(sandbox)
						return
					}
					break
				}
				if totalWritten >= config.MaxDownBytes {
					break
				}
			}
			_ = f.Close()

			dlTask.SetStatus("completed")
			dlTask.Progress = 100
			dlTask.Last = time.Now()
			task.Progress = 50

			if autoExtract {
				task.Message = "正在解压..."
				if extractArchive(fpath, sandbox) {
					_ = os.Remove(fpath)
					if cmd == "" {
						if bin := findBinaryInDir(sandbox); bin != "" {
							cmd = bin
						}
					}
				}
			} else if makeExec {
				task.Message = "设置权限..."
				_ = os.Chmod(fpath, 0755)
				if cmd == "" {
					cmd = "./" + fname
				}
			}
		}

		task.Progress = 80
		task.Message = "保存配置..."

		appOpMu.Lock()
		var finalApps map[string]models.Project
		_ = LoadJSON(config.ConfigApps, &finalApps)
		finalApps[name] = models.Project{
			Path:      sandbox,
			Cmd:       cmd,
			SetupCmd:  setupCmd,
			WorkDir:   "",
			SourceURL: down,
			Created:   time.Now().Format("2006-01-02 15:04"),
		}
		_ = WriteJSON(config.ConfigApps, finalApps)
		appOpMu.Unlock()

		task.Progress = 100
		task.Status = "completed"
		task.Message = "创建完成"

		time.AfterFunc(5*time.Minute, func() {
			createTasks.Delete(taskID)
		})
	}()

	json.NewEncoder(w).Encode(map[string]any{
		"ok":       true,
		"task":     taskID,
		"redirect": "/",
	})
}
