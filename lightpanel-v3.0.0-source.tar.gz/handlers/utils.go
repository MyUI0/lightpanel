package handlers

import (
	"encoding/json"
	"os"
	"path/filepath"
)

func LoadJSON(path string, v any) error {
	b, e := os.ReadFile(path)
	if e != nil {
		return e
	}
	return json.Unmarshal(b, v)
}

func WriteJSON(path string, v any) error {
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}

	tmp := path + ".tmp"
	f, e := os.Create(tmp)
	if e != nil {
		return e
	}

	enc := json.NewEncoder(f)
	enc.SetIndent("", "  ")
	err := enc.Encode(v)
	if err == nil {
		err = f.Close()
	} else {
		f.Close()
	}

	if err != nil {
		_ = os.Remove(tmp)
		return err
	}

	return os.Rename(tmp, path)
}

func EnsureDir(path string) error {
	return os.MkdirAll(path, 0755)
}

func GetBgUrl() string {
	var bg models.BgConfig
	_ = LoadJSON(config.ConfigBg, &bg)
	return bg.URL
}

func GetBgUrl() string {
	var bg models.BgConfig
	_ = LoadJSON(config.ConfigBg, &bg)
	return bg.URL
}
