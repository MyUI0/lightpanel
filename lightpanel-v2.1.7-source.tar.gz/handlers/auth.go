package handlers

import (
	"crypto/sha256"
	"encoding/hex"
	"net/http"
	"time"

	"lightpanel/config"
	"lightpanel/models"
)

func hash(s string) string {
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:])
}

func auth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var usr models.UserConfig
		_ = LoadJSON(config.ConfigUsr, &usr)

		cookie, _ := r.Cookie("lp_session")
		if cookie != nil && cookie.Value == hash(usr.Password) {
			next(w, r)
			return
		}

		http.Redirect(w, r, "/login", 302)
	}
}

func loginPage(w http.ResponseWriter, r *http.Request) {
	err := r.URL.Query().Get("err")
	_ = htmlRender.ExecuteTemplate(w, "login", err)
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	_ = r.ParseForm()
	user := r.Form.Get("username")
	pass := r.Form.Get("password")

	var usr models.UserConfig
	_ = LoadJSON(config.ConfigUsr, &usr)

	if user == usr.Username && pass == usr.Password {
		http.SetCookie(w, &http.Cookie{
			Name:     "lp_session",
			Value:    hash(usr.Password),
			Path:     "/",
			Expires:  time.Now().Add(24 * time.Hour),
			HttpOnly: true,
		})
		http.Redirect(w, r, "/", 302)
		return
	}
	http.Redirect(w, r, "/login?err=1", 302)
}

func logoutHandler(w http.ResponseWriter, r *http.Request) {
	http.SetCookie(w, &http.Cookie{
		Name:   "lp_session",
		Value:  "",
		Path:   "/",
		MaxAge: -1,
	})
	http.Redirect(w, r, "/login", 302)
}

func requirePOST(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			w.WriteHeader(405)
			_, _ = w.Write([]byte("Method Not Allowed"))
			return
		}
		next(w, r)
	}
}
