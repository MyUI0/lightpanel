#!/bin/bash
set -e

echo "=== LightPanel 一键编译脚本 ==="

# 检查 Go
if ! command -v go &> /dev/null; then
    echo "[错误] 未检测到 Go，请先安装:"
    echo "  wget https://go.dev/dl/go1.22.5.linux-amd64.tar.gz"
    echo "  rm -rf /usr/local/go && tar -C /usr/local -xzf go1.22.5.linux-amd64.tar.gz"
    echo '  export PATH=$PATH:/usr/local/go/bin'
    exit 1
fi

echo "[OK] Go $(go version)"

# 设置国内代理
export GOPROXY=https://goproxy.cn,direct

echo "[1/3] 下载依赖..."
go mod tidy

echo "[2/3] 编译..."
go build -ldflags="-s -w" -o lightpanel .

echo "[3/3] 完成!"
echo ""
echo "运行: ./lightpanel"
echo "访问: http://127.0.0.1:31956"
echo "账号: admin / admin"
