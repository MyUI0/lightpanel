package main

import (
	"log"

	"lightpanel/config"
	"lightpanel/handlers"
)

func main() {
	if err := handlers.InitConfig(); err != nil {
		log.Fatalf("配置初始化失败: %v", err)
	}

	handlers.CleanupSessions()
	handlers.InitTemplates()
	handlers.SetupRoutes()

	log.Printf("LightPanel %s", config.Version)
	log.Printf("端口: %s", config.Port)
	log.Printf("地址: http://0.0.0.0:%s", config.Port)
	log.Printf("数据: %s", config.DataDir)
	log.Printf("默认: admin / admin")

	if err := handlers.ListenAndServe(); err != nil {
		log.Fatalf("启动失败: %v", err)
	}
}
