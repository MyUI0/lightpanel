#!/bin/bash
set -e

VERSION="v2.2.2"
PKG="lightpanel-${VERSION}-source"

echo "=== LightPanel ${VERSION} 打包脚本 ==="

# 创建临时目录
TMPDIR=$(mktemp -d)
trap "rm -rf $TMPDIR" EXIT

# 复制源码
echo "[1/2] 复制源码..."
cp -r . "$TMPDIR/$PKG"
cd "$TMPDIR"

# 清理编译产物和旧包
rm -f "$PKG/lightpanel" "$PKG/lightpanel.exe"
rm -f "$PKG/lightpanel-"*-source.tar.gz

# 打包
echo "[2/2] 打包中..."
tar -czvf "${PKG}.tar.gz" "$PKG"

# 复制到桌面
DESKTOP="$HOME/Desktop"
if [ -d "$DESKTOP" ]; then
    cp "${PKG}.tar.gz" "$DESKTOP/"
    echo "已复制到桌面: $DESKTOP/${PKG}.tar.gz"
else
    echo "打包完成: $TMPDIR/${PKG}.tar.gz"
fi

echo "完成!"
