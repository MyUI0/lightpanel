package handlers

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"lightpanel/config"
	"lightpanel/models"
)

func createApp(w http.ResponseWriter, r *http.Request) {
	_ = r.ParseForm()
	name := strings.TrimSpace(r.Form.Get("name"))
	down := strings.TrimSpace(r.Form.Get("url"))
	cmd := strings.TrimSpace(r.Form.Get("cmd"))
	if name == "" || cmd == "" || strings.ContainsAny(name, `/\`) || strings.ContainsAny(name, `;&|'`) || strings.HasPrefix(name, ".") || strings.Contains(name, "..") {
		http.Redirect(w, r, "/", 302)
		return
	}

	var apps map[string]models.Project
	_ = LoadJSON(config.ConfigApps, &apps)
	if _, exists := apps[name]; exists {
		http.Redirect(w, r, "/", 302)
		return
	}

	sandbox := filepath.Join(config.AppsDir, name)
	if err := os.MkdirAll(sandbox, 0755); err != nil {
		http.Redirect(w, r, "/", 302)
		return
	}

	if down != "" {
		if !strings.HasPrefix(down, "http://") && !strings.HasPrefix(down, "https://") {
			http.Redirect(w, r, "/?err=download&msg=URL%E6%A0%BC%E5%BC%8F%E9%94%99%E8%AF%AF", 302)
			return
		}
		client := &http.Client{Timeout: 120 * time.Second}
		resp, e := client.Get(down)
		if e != nil {
			_ = os.RemoveAll(sandbox)
			http.Redirect(w, r, "/?err=download&msg="+strings.ReplaceAll(e.Error(), " ", "+"), 302)
			return
		}
		defer resp.Body.Close()
		if resp.StatusCode != 200 {
			_ = os.RemoveAll(sandbox)
			http.Redirect(w, r, "/?err=download&msg=HTTP+"+fmt.Sprint(resp.StatusCode), 302)
			return
		}
		fname := filepath.Base(down)
		if fname == "" || fname == "." || fname == "/" || fname == "." {
			fname = "download"
		}
		fpath := filepath.Join(sandbox, fname)
		f, err := os.Create(fpath)
		if err != nil {
			_ = os.RemoveAll(sandbox)
			http.Redirect(w, r, "/?err=download&msg="+strings.ReplaceAll(err.Error(), " ", "+"), 302)
			return
		}
		_, copyErr := io.CopyN(f, resp.Body, config.MaxDownBytes)
		_ = f.Close()
		if copyErr != nil && copyErr != io.EOF {
			_ = os.Remove(fpath)
			_ = os.RemoveAll(sandbox)
			http.Redirect(w, r, "/?err=download&msg="+strings.ReplaceAll(copyErr.Error(), " ", "+"), 302)
			return
		}

		if extractArchive(fpath, sandbox) {
			_ = os.Remove(fpath)
		} else if strings.HasSuffix(fname, ".sh") {
			_ = os.Chmod(fpath, 0755)
		}
	}

	apps[name] = models.Project{
		Path:    sandbox,
		Cmd:     cmd,
		Created: time.Now().Format("2006-01-02 15:04"),
	}
	_ = WriteJSON(config.ConfigApps, apps)
	http.Redirect(w, r, "/", 302)
}
