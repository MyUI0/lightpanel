package handlers

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"lightpanel/config"
	"lightpanel/models"
)

func createApp(w http.ResponseWriter, r *http.Request) {
	_ = r.ParseForm()
	name := strings.TrimSpace(r.Form.Get("name"))
	down := strings.TrimSpace(r.Form.Get("url"))
	cmd := strings.TrimSpace(r.Form.Get("cmd"))
	if name == "" || cmd == "" || strings.ContainsAny(name, `/\`) || strings.ContainsAny(name, `;&|'`) || strings.HasPrefix(name, ".") || strings.Contains(name, "..") {
		http.Redirect(w, r, "/", 302)
		return
	}

	var apps map[string]models.Project
	_ = LoadJSON(config.ConfigApps, &apps)
	if _, exists := apps[name]; exists {
		http.Redirect(w, r, "/", 302)
		return
	}

	sandbox := filepath.Join(config.AppsDir, name)
	if err := os.MkdirAll(sandbox, 0755); err != nil {
		http.Redirect(w, r, "/", 302)
		return
	}

	if down != "" {
		if !strings.HasPrefix(down, "http://") && !strings.HasPrefix(down, "https://") {
			http.Redirect(w, r, "/?err=download&msg=URL%E6%A0%BC%E5%BC%8F%E9%94%99%E8%AF%AF", 302)
			return
		}

		dlID := "dl_" + strconv.FormatInt(time.Now().UnixNano(), 36)
		task := &models.DownloadTask{
			ID:     dlID,
			Name:   name,
			URL:    down,
			Cmd:    cmd,
			Status: "downloading",
			Last:   time.Now(),
		}
		downloadTasks.Store(dlID, task)

		client := &http.Client{Timeout: 120 * time.Second}
		resp, e := client.Get(down)
		if e != nil {
			task.Status = "error"
			task.Last = time.Now()
			_ = os.RemoveAll(sandbox)
			http.Redirect(w, r, "/?err=download&msg="+strings.ReplaceAll(e.Error(), " ", "+"), 302)
			return
		}
		defer resp.Body.Close()
		if resp.StatusCode != 200 {
			task.Status = "error"
			task.Last = time.Now()
			_ = os.RemoveAll(sandbox)
			http.Redirect(w, r, "/?err=download&msg=HTTP+"+fmt.Sprint(resp.StatusCode), 302)
			return
		}
		task.Size = resp.ContentLength
		fname := filepath.Base(down)
		if fname == "" || fname == "." || fname == "/" || fname == "." {
			fname = "download"
		}
		fpath := filepath.Join(sandbox, fname)
		f, err := os.Create(fpath)
		if err != nil {
			task.Status = "error"
			task.Last = time.Now()
			_ = os.RemoveAll(sandbox)
			http.Redirect(w, r, "/?err=download&msg="+strings.ReplaceAll(err.Error(), " ", "+"), 302)
			return
		}
		_, copyErr := io.CopyN(f, resp.Body, config.MaxDownBytes)
		_ = f.Close()
		if copyErr != nil && copyErr != io.EOF {
			task.Status = "error"
			task.Last = time.Now()
			_ = os.Remove(fpath)
			_ = os.RemoveAll(sandbox)
			http.Redirect(w, r, "/?err=download&msg="+strings.ReplaceAll(copyErr.Error(), " ", "+"), 302)
			return
		}
		task.Status = "completed"
		task.Progress = 100
		task.Last = time.Now()

		if extractArchive(fpath, sandbox) {
			_ = os.Remove(fpath)
		} else if strings.HasSuffix(fname, ".sh") {
			_ = os.Chmod(fpath, 0755)
		}
	}

	apps[name] = models.Project{
		Path:      sandbox,
		Cmd:       cmd,
		WorkDir:   "",
		SourceURL: down,
		Created:   time.Now().Format("2006-01-02 15:04"),
	}
	_ = WriteJSON(config.ConfigApps, apps)

	if strings.HasSuffix(strings.ToLower(down), ".sh") || strings.Contains(strings.ToLower(down), "install") {
		appName := name
		appSandbox := sandbox
		go func() {
			time.Sleep(15 * time.Second)
			scanTime := time.Now().Add(-20 * time.Second)
			detWorkDir, detBin, note := detectNewExecutable(scanTime)
			var updated map[string]models.Project
			if err := LoadJSON(config.ConfigApps, &updated); err == nil {
				if app, ok := updated[appName]; ok {
					if detWorkDir != "" {
						app.WorkDir = detWorkDir
					}
					if detBin != "" {
						app.Cmd = detBin
					}
					updated[appName] = app
					_ = WriteJSON(config.ConfigApps, updated)
				}
			}
			_ = os.WriteFile(filepath.Join(appSandbox, "install_note.txt"), []byte(note), 0644)
		}()
	}

	http.Redirect(w, r, "/", 302)
}
