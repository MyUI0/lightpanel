package handlers

import (
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"lightpanel/config"
	"lightpanel/models"
)

var (
	downloadTasks sync.Map
)

func init() {
	go func() {
		for range time.Tick(10 * time.Minute) {
			downloadTasks.Range(func(key, value any) bool {
				if t, ok := value.(*models.DownloadTask); ok {
					if t.Status == "completed" || t.Status == "error" {
						if time.Since(t.Last) > 30*time.Minute {
							downloadTasks.Delete(key)
						}
					} else if t.Status == "downloading" && time.Since(t.Last) > 60*time.Minute {
						t.Status = "error"
						downloadTasks.Delete(key)
					}
				}
				return true
			})
		}
	}()
}

func getDownloadTask(id string) (*models.DownloadTask, bool) {
	val, ok := downloadTasks.Load(id)
	if !ok {
		return nil, false
	}
	t, ok := val.(*models.DownloadTask)
	return t, ok
}

func downloadPage(w http.ResponseWriter, r *http.Request) {
	var tasks []models.DownloadTask
	downloadTasks.Range(func(_, value any) bool {
		if t, ok := value.(*models.DownloadTask); ok {
			tasks = append(tasks, *t)
		}
		return true
	})
	_ = htmlRender.ExecuteTemplate(w, "downloads", tasks)
}

func apiDownloads(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	var tasks []models.DownloadTask
	downloadTasks.Range(func(_, value any) bool {
		if t, ok := value.(*models.DownloadTask); ok {
			tasks = append(tasks, *t)
		}
		return true
	})
	_ = json.NewEncoder(w).Encode(tasks)
}

func apiDownloadAction(w http.ResponseWriter, r *http.Request) {
	action := strings.TrimPrefix(r.URL.Path, "/dl/action/")
	parts := strings.SplitN(action, "/", 2)
	if len(parts) != 2 {
		w.WriteHeader(400)
		return
	}
	id, act := parts[0], parts[1]

	task, ok := getDownloadTask(id)
	if !ok {
		w.WriteHeader(404)
		return
	}

	switch act {
	case "pause":
		if task.Status == "downloading" {
			task.Status = "paused"
		}
	case "resume":
		if task.Status == "paused" {
			task.Status = "downloading"
			go resumeDownload(id)
		}
	case "delete":
		downloadTasks.Delete(id)
		if task.Status == "downloading" || task.Status == "paused" {
			fpath := filepath.Join(config.AppsDir, task.Name, filepath.Base(task.URL))
			_ = os.Remove(fpath)
		}
	case "install":
		if task.Status == "completed" {
			installDownloadedApp(id)
			downloadTasks.Delete(id)
		}
	}

	w.WriteHeader(200)
}

func resumeDownload(id string) {
	task, ok := getDownloadTask(id)
	if !ok {
		return
	}

	sandbox := filepath.Join(config.AppsDir, task.Name)
	fname := filepath.Base(task.URL)
	if fname == "" || fname == "." || fname == "/" {
		fname = "download"
	}
	fpath := filepath.Join(sandbox, fname)

	var startOffset int64
	if info, err := os.Stat(fpath); err == nil {
		startOffset = info.Size()
	}

	client := &http.Client{Timeout: 60 * time.Second}
	req, err := http.NewRequest("GET", task.URL, nil)
	if err != nil {
		task.Status = "error"
		task.Last = time.Now()
		return
	}
	if startOffset > 0 {
		req.Header.Set("Range", "bytes="+strconv.FormatInt(startOffset, 10)+"-")
	}
	resp, e := client.Do(req)
	if e != nil {
		task.Status = "error"
		task.Last = time.Now()
		return
	}
	defer resp.Body.Close()

	if startOffset > 0 && resp.StatusCode != http.StatusPartialContent {
		_ = os.Remove(fpath)
		startOffset = 0
	}

	f, err := os.OpenFile(fpath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		task.Status = "error"
		task.Last = time.Now()
		return
	}
	defer f.Close()

	if startOffset == 0 {
		task.Size = resp.ContentLength
		if task.Size <= 0 {
			task.Size = 0
		}
	} else {
		task.Downloaded = startOffset
	}

	buf := make([]byte, 32*1024)
	for task.Status == "downloading" {
		n, readErr := resp.Body.Read(buf)
		if n > 0 {
			if _, err := f.Write(buf[:n]); err != nil {
				task.Status = "error"
				task.Last = time.Now()
				break
			}
			task.Downloaded += int64(n)
			if task.Size > 0 {
				task.Progress = int(float64(task.Downloaded) / float64(task.Size) * 100)
			}
		}
		if readErr != nil {
			if !errors.Is(readErr, io.EOF) {
				task.Status = "error"
				task.Last = time.Now()
			}
			break
		}
	}

	if task.Status == "downloading" {
		task.Status = "completed"
		task.Progress = 100
		task.Last = time.Now()
	}
}

func installDownloadedApp(id string) {
	task, ok := getDownloadTask(id)
	if !ok {
		return
	}

	sandbox := filepath.Join(config.AppsDir, task.Name)
	fname := filepath.Base(task.URL)
	fpath := filepath.Join(sandbox, fname)

	if extractArchive(fpath, sandbox) {
		_ = os.Remove(fpath)
	} else if strings.HasSuffix(fname, ".sh") {
		_ = os.Chmod(fpath, 0755)
	}

	var apps map[string]models.Project
	_ = LoadJSON(config.ConfigApps, &apps)
	apps[task.Name] = models.Project{
		Path:    sandbox,
		Cmd:     task.Cmd,
		Created: time.Now().Format("2006-01-02 15:04"),
	}
	_ = WriteJSON(config.ConfigApps, apps)
}

const maxStoreResponseSize = 10 * 1024 * 1024 // 10MB

func startStoreInstall(w http.ResponseWriter, r *http.Request) {
	idx, _ := strconv.Atoi(strings.TrimPrefix(r.URL.Path, "/install/"))
	srcIdx, _ := strconv.Atoi(r.URL.Query().Get("source"))
	var srcs []models.StoreSource
	_ = LoadJSON(config.ConfigSrc, &srcs)
	if srcIdx < 0 || srcIdx >= len(srcs) || idx < 0 {
		http.Redirect(w, r, "/store", 302)
		return
	}

	client := &http.Client{Timeout: 10 * time.Second}
	resp, e := client.Get(srcs[srcIdx].URL)
	if e != nil {
		http.Redirect(w, r, "/store", 302)
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		http.Redirect(w, r, "/store", 302)
		return
	}

	var apps []models.StoreApp
	limitedReader := io.LimitReader(resp.Body, maxStoreResponseSize)
	_ = json.NewDecoder(limitedReader).Decode(&apps)
	if idx >= len(apps) {
		http.Redirect(w, r, "/store", 302)
		return
	}
	app := apps[idx]
	name := strings.TrimSpace(app.Name)
	if strings.ContainsAny(name, `./\ `) {
		http.Redirect(w, r, "/store", 302)
		return
	}

	if app.URL == "" {
		sandbox := filepath.Join(config.AppsDir, name)
		_ = os.MkdirAll(sandbox, 0755)
		var list map[string]models.Project
		_ = LoadJSON(config.ConfigApps, &list)
		list[name] = models.Project{
			Path:    sandbox,
			Cmd:     app.Cmd,
			Created: time.Now().Format("2006-01-02 15:04"),
		}
		_ = WriteJSON(config.ConfigApps, list)
		http.Redirect(w, r, "/", 302)
		return
	}

	if !strings.HasPrefix(app.URL, "http://") && !strings.HasPrefix(app.URL, "https://") {
		http.Redirect(w, r, "/store", 302)
		return
	}

	dlURL := app.URL
	dlName := name
	dlCmd := app.Cmd
	id := "dl_" + strconv.FormatInt(time.Now().UnixNano(), 36)
	task := &models.DownloadTask{
		ID:     id,
		Name:   dlName,
		URL:    dlURL,
		Cmd:    dlCmd,
		Size:   0,
		Status: "downloading",
		Last:   time.Now(),
	}
	downloadTasks.Store(id, task)

	go func() {
		sandbox := filepath.Join(config.AppsDir, dlName)
		_ = os.MkdirAll(sandbox, 0755)

		fname := filepath.Base(dlURL)
		if fname == "" || fname == "." || fname == "/" {
			fname = "download"
		}
		fpath := filepath.Join(sandbox, fname)

		dlClient := &http.Client{Timeout: 60 * time.Second}
		dlResp, e := dlClient.Get(dlURL)
		if e != nil {
			task.Status = "error"
			task.Last = time.Now()
			return
		}
		defer dlResp.Body.Close()

		task.Size = dlResp.ContentLength

		f, err := os.Create(fpath)
		if err != nil {
			task.Status = "error"
			return
		}

		buf := make([]byte, 32*1024)
		for task.Status == "downloading" {
			n, readErr := dlResp.Body.Read(buf)
			if n > 0 {
				if _, err := f.Write(buf[:n]); err != nil {
					task.Status = "error"
					task.Last = time.Now()
					break
				}
				task.Downloaded += int64(n)
				if task.Size > 0 {
					task.Progress = int(float64(task.Downloaded) / float64(task.Size) * 100)
				}
			}
			if readErr != nil {
				if !errors.Is(readErr, io.EOF) {
					task.Status = "error"
					task.Last = time.Now()
				}
				break
			}
		}
		_ = f.Close()

		if task.Status == "downloading" {
			task.Status = "completed"
			task.Progress = 100
			task.Last = time.Now()
			if extractArchive(fpath, sandbox) {
				_ = os.Remove(fpath)
			} else if strings.HasSuffix(fname, ".sh") {
				_ = os.Chmod(fpath, 0755)
			}
		}
	}()

	http.Redirect(w, r, "/downloads", 302)
}

func storePage(w http.ResponseWriter, r *http.Request) {
	var srcs []models.StoreSource
	_ = LoadJSON(config.ConfigSrc, &srcs)
	idx, _ := strconv.Atoi(r.URL.Query().Get("source"))
	if idx < 0 || idx >= len(srcs) {
		idx = 0
	}

	var apps []models.StoreApp
	if len(srcs) > 0 {
		client := &http.Client{Timeout: 10 * time.Second}
		resp, e := client.Get(srcs[idx].URL)
		if e == nil {
			defer resp.Body.Close()
			if resp.StatusCode == 200 {
				limitedReader := io.LimitReader(resp.Body, maxStoreResponseSize)
				_ = json.NewDecoder(limitedReader).Decode(&apps)
			}
		}
	}
	if len(apps) == 0 {
		apps = []models.StoreApp{{
			Name:   "获取失败",
			Desc:   "网络异常或源地址错误",
			Icon:   "",
			Author: "system",
		}}
	}

	_ = htmlRender.ExecuteTemplate(w, "store", map[string]any{
		"Apps":    apps,
		"Sources": srcs,
		"Active":  idx,
	})
}
