package handlers

import (
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"time"
)

var commonBinPaths = []string{
	"/usr/local/bin",
	"/usr/bin",
	"/opt",
	"/root",
	"/home",
}

func detectNewExecutable(before time.Time) (workDir string, binary string, note string) {
	var candidates []struct {
		path string
		mod  time.Time
	}

	for _, dir := range commonBinPaths {
		_ = filepath.WalkDir(dir, func(path string, d fs.DirEntry, err error) error {
			if err != nil {
				return nil
			}
			if d.IsDir() {
				depth := strings.Count(strings.TrimPrefix(path, dir), string(os.PathSeparator))
				if depth > 3 {
					return fs.SkipDir
				}
				return nil
			}
			info, err := d.Info()
			if err != nil {
				return nil
			}
			if info.Mode()&0111 != 0 && info.ModTime().After(before) {
				candidates = append(candidates, struct {
					path string
					mod  time.Time
				}{path, info.ModTime()})
			}
			return nil
		})
	}

	if len(candidates) == 0 {
		return "", "", "自动检测未发现新安装的可执行文件，请手动设置工作目录和启动命令"
	}

	latest := candidates[0]
	for _, c := range candidates {
		if c.mod.After(latest.mod) {
			latest = c
		}
	}

	workDir = filepath.Dir(latest.path)
	binary = "./" + filepath.Base(latest.path)
	note = "自动检测到: " + latest.path
	return
}

func checkProcessAlive(pidFile string) bool {
	b, err := os.ReadFile(pidFile)
	if err != nil {
		return false
	}
	content := strings.TrimSpace(string(b))
	pid := 0
	for _, c := range content {
		if c >= '0' && c <= '9' {
			pid = pid*10 + int(c-'0')
		}
	}
	if pid <= 0 {
		return false
	}
	p, err := os.FindProcess(pid)
	if err != nil {
		return false
	}
	return p.Signal(syscall.Signal(0)) == nil
}
