package handlers

import (
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"time"
)

var commonBinPaths = []string{
	"/usr/local/bin",
	"/usr/bin",
	"/bin",
	"/opt",
	"/root",
	"/home",
	"/usr/local",
	"/usr/lib",
}

func detectNewExecutable(before time.Time) (workDir string, binary string, note string) {
	var candidates []struct {
		path string
		mod  time.Time
	}

	for _, dir := range commonBinPaths {
		if _, err := os.Stat(dir); err != nil {
			continue
		}
		_ = filepath.WalkDir(dir, func(path string, d fs.DirEntry, err error) error {
			if err != nil {
				return nil
			}
			if d.IsDir() {
				rel, _ := filepath.Rel(dir, path)
				depth := 0
				if rel != "." {
					depth = len(strings.Split(rel, string(os.PathSeparator)))
				}
				if depth > 5 {
					return fs.SkipDir
				}
				return nil
			}
			info, err := d.Info()
			if err != nil {
				return nil
			}
			modTime := info.ModTime()
			if modTime.Before(before) {
				return nil
			}
			if info.Mode()&0111 == 0 {
				return nil
			}
			if info.Size() < 100 {
				return nil
			}
			base := filepath.Base(path)
			if base == "find" || base == "xargs" || base == "grep" || base == "ls" || base == "cat" || base == "chmod" || base == "chown" || base == "mkdir" || base == "rm" || base == "cp" || base == "mv" {
				return nil
			}
			candidates = append(candidates, struct {
				path string
				mod  time.Time
			}{path, modTime})
			return nil
		})
	}

	if len(candidates) == 0 {
		return "", "", "自动检测未发现新安装的可执行文件，请手动设置工作目录和启动命令"
	}

	latest := candidates[0]
	for _, c := range candidates {
		if c.mod.After(latest.mod) {
			latest = c
		}
	}

	workDir = filepath.Dir(latest.path)
	binary = "./" + filepath.Base(latest.path)
	note = "自动检测到: " + latest.path + " (大小 " + formatDetectedSize(latest.path) + ")"
	return
}

func formatDetectedSize(path string) string {
	info, err := os.Stat(path)
	if err != nil {
		return "?"
	}
	s := info.Size()
	if s > 1024*1024 {
		return formatSizeMB(s)
	}
	if s > 1024 {
		return formatSizeKB(s)
	}
	return "0 B"
}

func formatSizeMB(b int64) string {
	v := float64(b) / (1024 * 1024)
	if v >= 10 {
		return fmt.Sprintf("%.0f MB", v)
	}
	return fmt.Sprintf("%.1f MB", v)
}

func formatSizeKB(b int64) string {
	v := float64(b) / 1024
	if v >= 10 {
		return fmt.Sprintf("%.0f KB", v)
	}
	return fmt.Sprintf("%.1f KB", v)
}

func checkProcessAlive(pidFile string) bool {
	b, err := os.ReadFile(pidFile)
	if err != nil {
		return false
	}
	content := strings.TrimSpace(string(b))
	pid := 0
	for _, c := range content {
		if c >= '0' && c <= '9' {
			pid = pid*10 + int(c-'0')
		}
	}
	if pid <= 0 {
		return false
	}
	p, err := os.FindProcess(pid)
	if err != nil {
		return false
	}
	return p.Signal(syscall.Signal(0)) == nil
}
