package handlers

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"lightpanel/config"
	"lightpanel/models"
)

const sessionDir = config.ConfigDir + "/sessions"

func hash(s string) string {
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:])
}

func generateSessionToken() string {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return ""
	}
	return hex.EncodeToString(b)
}

func isValidSession(token string) bool {
	if token == "" {
		return false
	}
	sessionFile := filepath.Join(sessionDir, token+".json")
	b, err := os.ReadFile(sessionFile)
	if err != nil {
		return false
	}
	var sess struct {
		Expires int64 `json:"expires"`
	}
	if err := json.Unmarshal(b, &sess); err != nil {
		return false
	}
	if time.Now().Unix() > sess.Expires {
		_ = os.Remove(sessionFile)
		return false
	}
	return true
}

func createSession(w http.ResponseWriter) string {
	token := generateSessionToken()
	if token == "" {
		return ""
	}
	if err := os.MkdirAll(sessionDir, 0700); err != nil {
		return ""
	}
	sessData, _ := json.Marshal(map[string]int64{
		"expires": time.Now().Add(24 * time.Hour).Unix(),
	})
	_ = os.WriteFile(filepath.Join(sessionDir, token+".json"), sessData, 0600)
	http.SetCookie(w, &http.Cookie{
		Name:     "lp_session",
		Value:    token,
		Path:     "/",
		Expires:  time.Now().Add(24 * time.Hour),
		HttpOnly: true,
		SameSite: http.SameSiteStrictMode,
	})
	return token
}

func destroySession(token string) {
	if token != "" {
		_ = os.Remove(filepath.Join(sessionDir, token+".json"))
	}
}

func CleanupSessions() {
	files, _ := os.ReadDir(sessionDir)
	for _, f := range files {
		b, err := os.ReadFile(filepath.Join(sessionDir, f.Name()))
		if err != nil {
			continue
		}
		var sess struct {
			Expires int64 `json:"expires"`
		}
		if json.Unmarshal(b, &sess) == nil && time.Now().Unix() > sess.Expires {
			_ = os.Remove(filepath.Join(sessionDir, f.Name()))
		}
	}
}

func auth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		cookie, _ := r.Cookie("lp_session")
		if cookie != nil && isValidSession(cookie.Value) {
			next(w, r)
			return
		}

		http.Redirect(w, r, "/login", 302)
	}
}

func loginPage(w http.ResponseWriter, r *http.Request) {
	err := r.URL.Query().Get("err")
	_ = htmlRender.ExecuteTemplate(w, "login", err)
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	_ = r.ParseForm()
	user := r.Form.Get("username")
	pass := r.Form.Get("password")

	var usr models.UserConfig
	if err := LoadJSON(config.ConfigUsr, &usr); err != nil {
		http.Redirect(w, r, "/login?err=1", 302)
		return
	}

	if user == usr.Username && hash(pass) == usr.Password {
		createSession(w)
		http.Redirect(w, r, "/", 302)
		return
	}
	http.Redirect(w, r, "/login?err=1", 302)
}

func logoutHandler(w http.ResponseWriter, r *http.Request) {
	cookie, _ := r.Cookie("lp_session")
	destroySession(cookie.Value)
	http.SetCookie(w, &http.Cookie{
		Name:     "lp_session",
		Value:    "",
		Path:     "/",
		MaxAge:   -1,
		HttpOnly: true,
		SameSite: http.SameSiteStrictMode,
	})
	http.Redirect(w, r, "/login", 302)
}

func requirePOST(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			w.WriteHeader(405)
			_, _ = w.Write([]byte("Method Not Allowed"))
			return
		}
		next(w, r)
	}
}

func InitConfig() error {
	if err := EnsureDir(config.ConfigDir); err != nil {
		return err
	}
	if err := EnsureDir(config.AppsDir); err != nil {
		return err
	}

	if _, e := os.Stat(config.ConfigApps); e != nil {
		if err := WriteJSON(config.ConfigApps, map[string]models.Project{}); err != nil {
			return err
		}
	}
	if _, e := os.Stat(config.ConfigSrc); e != nil {
		if err := WriteJSON(config.ConfigSrc, []models.StoreSource{}); err != nil {
			return err
		}
	}
	if _, e := os.Stat(config.ConfigUsr); e != nil {
		if err := WriteJSON(config.ConfigUsr, models.UserConfig{Username: "admin", Password: hash("admin")}); err != nil {
			return err
		}
	}
	if _, e := os.Stat(config.ConfigBg); e != nil {
		if err := WriteJSON(config.ConfigBg, models.BgConfig{Type: "gradient", URL: ""}); err != nil {
			return err
		}
	}
	return nil
}
