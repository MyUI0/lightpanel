package handlers

import (
	"crypto/sha256"
	"encoding/hex"
	"net/http"
	"os"
	"time"

	"lightpanel/config"
	"lightpanel/models"
)

func hash(s string) string {
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:])
}

func auth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var usr models.UserConfig
		if err := LoadJSON(config.ConfigUsr, &usr); err != nil {
			http.Redirect(w, r, "/login", 302)
			return
		}

		cookie, _ := r.Cookie("lp_session")
		// Cookie value = hash(stored_password_hash), validated consistently with loginHandler
		if cookie != nil && cookie.Value == hash(usr.Password) {
			http.SetCookie(w, &http.Cookie{
				Name:     "lp_session",
				Value:    cookie.Value,
				Path:     "/",
				Expires:  time.Now().Add(24 * time.Hour),
				HttpOnly: true,
				SameSite: http.SameSiteStrictMode,
			})
			next(w, r)
			return
		}

		http.Redirect(w, r, "/login", 302)
	}
}

func loginPage(w http.ResponseWriter, r *http.Request) {
	err := r.URL.Query().Get("err")
	_ = htmlRender.ExecuteTemplate(w, "login", err)
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	_ = r.ParseForm()
	user := r.Form.Get("username")
	pass := r.Form.Get("password")

	var usr models.UserConfig
	if err := LoadJSON(config.ConfigUsr, &usr); err != nil {
		http.Redirect(w, r, "/login?err=1", 302)
		return
	}

	if user == usr.Username && hash(pass) == usr.Password {
		http.SetCookie(w, &http.Cookie{
			Name:     "lp_session",
			Value:    hash(usr.Password),
			Path:     "/",
			Expires:  time.Now().Add(24 * time.Hour),
			HttpOnly: true,
			SameSite: http.SameSiteStrictMode,
		})
		http.Redirect(w, r, "/", 302)
		return
	}
	http.Redirect(w, r, "/login?err=1", 302)
}

func logoutHandler(w http.ResponseWriter, r *http.Request) {
	http.SetCookie(w, &http.Cookie{
		Name:     "lp_session",
		Value:    "",
		Path:     "/",
		MaxAge:   -1,
		HttpOnly: true,
		SameSite: http.SameSiteStrictMode,
	})
	http.Redirect(w, r, "/login", 302)
}

func requirePOST(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			w.WriteHeader(405)
			_, _ = w.Write([]byte("Method Not Allowed"))
			return
		}
		next(w, r)
	}
}

func InitConfig() error {
	if err := EnsureDir(config.ConfigDir); err != nil {
		return err
	}
	if err := EnsureDir(config.AppsDir); err != nil {
		return err
	}

	if _, e := os.Stat(config.ConfigApps); e != nil {
		if err := WriteJSON(config.ConfigApps, map[string]models.Project{}); err != nil {
			return err
		}
	}
	if _, e := os.Stat(config.ConfigSrc); e != nil {
		if err := WriteJSON(config.ConfigSrc, []models.StoreSource{}); err != nil {
			return err
		}
	}
	if _, e := os.Stat(config.ConfigUsr); e != nil {
		if err := WriteJSON(config.ConfigUsr, models.UserConfig{Username: "admin", Password: hash("admin")}); err != nil {
			return err
		}
	}
	if _, e := os.Stat(config.ConfigBg); e != nil {
		if err := WriteJSON(config.ConfigBg, models.BgConfig{Type: "gradient", URL: ""}); err != nil {
			return err
		}
	}
	return nil
}
