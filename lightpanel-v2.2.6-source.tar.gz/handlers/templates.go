package handlers

const htmlLogin = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>登录 - LightPanel</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',system-ui,-apple-system,sans-serif; }
body { min-height:100vh; display:flex; align-items:center; justify-content:center; background:linear-gradient(135deg,#667eea 0%,#764ba2 100%); position:relative; overflow:hidden; }
body::before { content:''; position:absolute; inset:0; background-image:radial-gradient(rgba(255,255,255,0.08) 1px,transparent 1px); background-size:30px 30px; }
.card { position:relative; z-index:1; background:rgba(255,255,255,0.95); backdrop-filter:blur(20px); border-radius:24px; padding:2.5rem; width:380px; box-shadow:0 20px 60px rgba(0,0,0,0.3); }
.logo { width:56px; height:56px; background:linear-gradient(135deg,#6366f1,#a855f7); border-radius:16px; display:flex; align-items:center; justify-content:center; margin:0 auto 1.5rem; }
.logo i { color:#fff; font-size:1.5rem; }
h1 { text-align:center; font-size:1.5rem; font-weight:700; color:#1a1a2e; margin-bottom:0.5rem; }
.subtitle { text-align:center; font-size:0.85rem; color:#6b7280; margin-bottom:2rem; }
.field { margin-bottom:1rem; }
.field label { display:block; font-size:0.8rem; font-weight:600; color:#374151; margin-bottom:0.4rem; }
.field input { width:100%; padding:0.75rem 1rem; border-radius:12px; border:2px solid #e5e7eb; font-size:0.9rem; transition:all 0.2s; outline:none; }
.field input:focus { border-color:#6366f1; box-shadow:0 0 0 3px rgba(99,102,241,0.15); }
.btn { width:100%; padding:0.85rem; border-radius:12px; border:none; background:linear-gradient(135deg,#6366f1,#7c3aed); color:#fff; font-size:0.95rem; font-weight:600; cursor:pointer; transition:all 0.2s; margin-top:0.5rem; }
.btn:hover { box-shadow:0 8px 25px rgba(99,102,241,0.4); transform:translateY(-1px); }
.err { background:#fef2f2; color:#dc2626; padding:0.65rem 1rem; border-radius:10px; font-size:0.8rem; margin-bottom:1rem; text-align:center; border:1px solid #fecaca; }
.footer { text-align:center; font-size:0.7rem; color:#9ca3af; margin-top:1.5rem; }
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
<div class="card">
  <div class="logo"><i class="fa-solid fa-server"></i></div>
  <h1>LightPanel</h1>
  <p class="subtitle">服务器管理面板</p>
  {{if eq . "1"}}
  <div class="err"><i class="fa-solid fa-circle-exclamation" style="margin-right:0.3rem;"></i>用户名或密码错误</div>
  {{end}}
  <form action="/login/auth" method="post">
    <div class="field">
      <label>用户名</label>
      <input name="username" placeholder="请输入用户名" required autocomplete="username">
    </div>
    <div class="field">
      <label>密码</label>
      <input name="password" type="password" placeholder="请输入密码" required autocomplete="current-password">
    </div>
    <button class="btn" type="submit"><i class="fa-solid fa-right-to-bracket" style="margin-right:0.5rem;"></i>登录</button>
  </form>
  <div class="footer">LightPanel · AI 辅助开发</div>
</div>
</body>
</html>`

const htmlIndex = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>LightPanel 管理面板</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
:root { --accent:#6366f1; --accent-glow:rgba(99,102,241,0.4); --bg:#0f0f23; --bg-card:rgba(255,255,255,0.06); --bg-glass:rgba(255,255,255,0.08); --text:#fff; --text-dim:rgba(255,255,255,0.4); --border:rgba(255,255,255,0.1); --input-bg:rgba(255,255,255,0.06); --input-border:rgba(255,255,255,0.12); --input-text:#fff; --input-ph:rgba(255,255,255,0.3); }
[data-theme="light"] { --bg:#e8eaed; --bg-card:rgba(255,255,255,0.85); --bg-glass:rgba(255,255,255,0.6); --text:#1a1a2e; --text-dim:rgba(0,0,0,0.5); --border:rgba(0,0,0,0.1); --input-bg:rgba(255,255,255,0.9); --input-border:rgba(0,0,0,0.15); --input-text:#1a1a2e; --input-ph:rgba(0,0,0,0.35); }
* { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',system-ui,sans-serif; }
body { background:var(--bg); min-height:100vh; position:relative; }
.bg-layer { position:fixed; inset:0; z-index:0; background:radial-gradient(ellipse at 50% 50%,rgba(99,102,241,0.12) 0%,transparent 60%),var(--bg); }
.container { position:relative; z-index:1; max-width:900px; margin:0 auto; padding:1.5rem; }
.glass { background:var(--bg-card); backdrop-filter:blur(20px) saturate(180%); border:1px solid var(--border); border-radius:16px; }
.glass-card { background:var(--bg-card); backdrop-filter:blur(20px) saturate(180%); border:1px solid var(--border); border-radius:16px; padding:1.25rem; margin-bottom:0.75rem; transition:all 0.3s ease; }
.glass-card:hover { background:var(--bg-glass); }
.btn { display:inline-flex; align-items:center; justify-content:center; gap:0.5rem; padding:0.6rem 1.2rem; border-radius:12px; font-size:0.875rem; font-weight:500; transition:all 0.2s ease; cursor:pointer; border:none; text-decoration:none; }
.btn-primary { background:linear-gradient(135deg,#6366f1,#7c3aed); color:#fff; }
.btn-primary:hover { box-shadow:0 4px 20px rgba(99,102,241,0.4); }
.btn-ghost { background:var(--bg-glass); color:var(--text); border:1px solid var(--border); backdrop-filter:blur(12px); }
.btn-ghost:hover { background:var(--border); color:var(--text); }
.btn-danger { background:linear-gradient(135deg,#ef4444,#dc2626); color:#fff; }
.btn-success { background:linear-gradient(135deg,#10b981,#059669); color:#fff; }
.btn-warning { background:linear-gradient(135deg,#f59e0b,#d97706); color:#fff; }
.btn-sm { padding:0.4rem 0.8rem; font-size:0.75rem; border-radius:8px; }
.input { width:100%; padding:0.75rem 1rem; border-radius:12px; background:var(--input-bg); border:1px solid var(--input-border); color:var(--input-text); font-size:0.875rem; }
.input:focus { outline:none; border-color:#6366f1; box-shadow:0 0 0 3px rgba(99,102,241,0.3); }
.input::placeholder { color:var(--input-ph); }
.alert { padding:0.75rem 1rem; border-radius:10px; font-size:0.85rem; margin-bottom:1rem; }
.alert-error { background:rgba(239,68,68,0.15); color:#f87171; border:1px solid rgba(239,68,68,0.3); }
.alert-success { background:rgba(16,185,129,0.15); color:#34d399; border:1px solid rgba(16,185,129,0.3); }
.badge { display:inline-flex; align-items:center; gap:0.35rem; padding:0.3rem 0.75rem; border-radius:9999px; font-size:0.75rem; font-weight:500; }
.badge-running { background:rgba(16,185,129,0.15); color:#34d399; border:1px solid rgba(16,185,129,0.3); }
.badge-stopped { background:rgba(239,68,68,0.15); color:#f87171; border:1px solid rgba(239,68,68,0.3); }
.stat-card { text-align:center; padding:1rem; }
.stat-value { font-size:1.5rem; font-weight:700; color:var(--text); }
.stat-label { font-size:0.75rem; color:var(--text-dim); margin-top:0.25rem; }
.app-item { display:flex; align-items:center; gap:1rem; }
.app-name { font-weight:600; color:var(--text); font-size:0.95rem; }
.app-cmd { font-size:0.75rem; color:var(--text-dim); margin-top:0.25rem; }
.progress-ring { width:48px; height:48px; }
.check-label { display:flex; align-items:center; gap:0.5rem; padding:0.75rem 1rem; border-radius:12px; background:var(--bg-glass); border:1px solid var(--border); cursor:pointer; transition:all 0.2s; }
.check-label:has(input:checked) { background:rgba(16,185,129,0.1); border-color:rgba(16,185,129,0.3); }
.check-label input { display:none; }
.check-box { width:20px; height:20px; border-radius:6px; border:2px solid var(--input-border); display:flex; align-items:center; justify-content:center; transition:all 0.2s; }
.check-label:has(input:checked) .check-box { background:#10b981; border-color:#10b981; }
.fail-card { background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.3); border-radius:12px; padding:1rem; margin-bottom:1rem; }
.fail-card h4 { color:#f87171; font-size:0.9rem; margin-bottom:0.5rem; }
.fail-card pre { font-size:0.75rem; color:var(--text-dim); white-space:pre-wrap; word-break:break-all; max-height:150px; overflow-y:auto; }
.deps-list { display:flex; gap:0.5rem; flex-wrap:wrap; margin-top:0.5rem; }
.dep-tag { background:rgba(245,158,11,0.15); color:#fbbf24; padding:0.2rem 0.6rem; border-radius:6px; font-size:0.7rem; }
.progress-bar { width:100%; height:8px; background:rgba(255,255,255,0.08); border-radius:4px; overflow:hidden; }
.progress-fill { height:100%; background:linear-gradient(90deg,#6366f1,#a855f7); border-radius:4px; transition:width 0.3s ease; }
</style>
</head>
<body>
<div class="bg-layer"{{if .BgUrl}} style="background-image:url('{{.BgUrl}}');background-size:cover;background-position:center;background-repeat:no-repeat;"{{end}}></div>
<div class="container">
<div style="display:flex;align-items:center;gap:1rem;margin-bottom:2rem;">
  <h1 style="font-size:1.5rem;font-weight:700;color:var(--text);"><i class="fa-solid fa-server" style="color:#6366f1;margin-right:0.5rem;"></i>LightPanel</h1>
  <a href="/store" class="btn btn-ghost"><i class="fa-solid fa-store"></i>商店</a>
  <a href="/downloads" class="btn btn-ghost"><i class="fa-solid fa-download"></i>下载</a>
  <a href="/system" class="btn btn-ghost"><i class="fa-solid fa-chart-line"></i>监控</a>
  <a href="/setting" class="btn btn-ghost"><i class="fa-solid fa-gear"></i></a>
  <button id="themeBtn" class="btn btn-ghost" title="切换主题"><i class="fa-solid fa-moon"></i></button>
  <a href="/logout" class="btn btn-ghost" style="color:#f87171;" title="退出"><i class="fa-solid fa-right-from-bracket"></i></a>
</div>

{{if .FailInfo}}
<div class="fail-card">
  <h4><i class="fa-solid fa-triangle-exclamation" style="margin-right:0.5rem;"></i>应用启动失败: {{.FailInfo.Name}}{{if gt .FailInfo.Count 1}} (及其他应用){{end}}</h4>
  {{if .FailInfo.Deps}}
  <div class="deps-list">
    {{range .FailInfo.Deps}}
    <span class="dep-tag"><i class="fa-solid fa-circle-exclamation" style="margin-right:0.3rem;"></i>缺少: {{.}}</span>
    {{end}}
  </div>
  {{end}}
  <pre>{{.FailInfo.Log}}</pre>
</div>
{{end}}

{{if .CreateErr}}
<div class="fail-card">
  <h4><i class="fa-solid fa-circle-xmark" style="margin-right:0.5rem;"></i>创建应用失败: {{.CreateErr}}</h4>
</div>
{{end}}

<div id="activeTaskBanner" style="display:none;" class="fail-card" style="background:rgba(99,102,241,0.1);border-color:rgba(99,102,241,0.3);">
  <h4><i class="fa-solid fa-spinner fa-spin" style="margin-right:0.5rem;"></i><span id="activeTaskMsg">正在创建...</span></h4>
  <div class="progress-bar" style="height:6px;margin-top:0.5rem;"><div class="progress-fill" id="activeTaskFill" style="width:0%"></div></div>
</div>

<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:0.75rem;margin-bottom:1.5rem;">
  <div class="glass stat-card">
    <div class="stat-value">{{.Cpu}}%</div>
    <div class="stat-label"><i class="fa-solid fa-microchip" style="margin-right:0.3rem;"></i>CPU</div>
  </div>
  <div class="glass stat-card">
    <div class="stat-value">{{.Mem}}%</div>
    <div class="stat-label"><i class="fa-solid fa-memory" style="margin-right:0.3rem;"></i>内存</div>
  </div>
  <div class="glass stat-card">
    <div class="stat-value">{{.Disk}}%</div>
    <div class="stat-label"><i class="fa-solid fa-hard-drive" style="margin-right:0.3rem;"></i>磁盘</div>
  </div>
  <div class="glass stat-card">
    <div class="stat-value">{{.ProcNum}}</div>
    <div class="stat-label"><i class="fa-solid fa-list" style="margin-right:0.3rem;"></i>进程</div>
  </div>
</div>
<div style="font-size:0.75rem;color:var(--text-dim);margin-bottom:1.5rem;text-align:center;">
  <i class="fa-solid fa-clock" style="margin-right:0.3rem;"></i>运行时间: {{.Uptime}}
</div>

<div class="glass" style="padding:1.5rem;margin-bottom:1.5rem;">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;">
    <h3 style="font-size:1.1rem;font-weight:600;color:var(--text);"><i class="fa-solid fa-cube" style="color:#6366f1;margin-right:0.5rem;"></i>应用管理</h3>
  </div>
  <form id="createForm" style="display:grid;gap:0.75rem;margin-bottom:1rem;">
    <input name="name" placeholder="应用名称（英文/数字）" required class="input" id="appName">
    <input name="url" placeholder="下载地址（可选，支持 .tar.gz/.zip/.sh/二进制等）" class="input" id="appUrl">
    <input name="setup_cmd" placeholder="首次运行命令（可选，仅执行一次）" class="input" id="appSetup">
    <input name="cmd" placeholder="启动命令（留空则自动检测）" class="input" id="appCmd">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;">
      <label class="check-label" style="justify-content:center;">
        <input type="checkbox" name="auto_extract" id="autoExtract">
        <div class="check-box"><i class="fa-solid fa-check" style="font-size:0.7rem;color:#fff;"></i></div>
        <span style="color:var(--text-dim);font-size:0.8rem;">自动解压（tar.gz/zip/tar/xz/bz2）</span>
      </label>
      <label class="check-label" style="justify-content:center;">
        <input type="checkbox" name="make_exec" id="makeExec" checked>
        <div class="check-box"><i class="fa-solid fa-check" style="font-size:0.7rem;color:#fff;"></i></div>
        <span style="color:var(--text-dim);font-size:0.8rem;">赋予运行权限（chmod +x）</span>
      </label>
    </div>
    <button class="btn btn-primary" style="width:100%;" type="submit" id="createBtn"><i class="fa-solid fa-plus"></i>创建应用</button>
  </form>
  <div id="createProgress" style="display:none;">
    <div class="progress-bar" style="height:6px;margin-bottom:0.5rem;"><div class="progress-fill" id="progressFill" style="width:0%"></div></div>
    <p style="font-size:0.75rem;color:var(--text-dim);text-align:center;" id="progressText">准备中...</p>
  </div>
</div>

{{range $name, $app := .Apps}}
<div class="glass-card app-item">
  <div style="flex:1;">
    <div style="display:flex;align-items:center;gap:0.75rem;">
      <span class="app-name">{{$name}}</span>
      {{if eq $app.Status "运行中"}}
      <span class="badge badge-running"><span style="width:6px;height:6px;background:#34d399;border-radius:50%;"></span>运行中</span>
      {{else}}
      <span class="badge badge-stopped"><span style="width:6px;height:6px;background:#f87171;border-radius:50%;"></span>已停止</span>
      {{end}}
      {{if $app.AutoStart}}
      <span class="badge" style="background:rgba(59,130,246,0.15);color:#60a5fa;border:1px solid rgba(59,130,246,0.3);"><i class="fa-solid fa-rotate" style="margin-right:0.3rem;"></i>自启</span>
      {{end}}
    </div>
    <div class="app-cmd"><i class="fa-solid fa-terminal" style="margin-right:0.3rem;"></i>{{$app.Cmd}}</div>
    <div class="app-cmd"><i class="fa-solid fa-folder" style="margin-right:0.3rem;"></i>{{$app.Path}}{{if $app.WorkDir}} → <span style="color:#60a5fa;">{{$app.WorkDir}}</span>{{end}}</div>
  </div>
  <div style="display:flex;gap:0.4rem;flex-wrap:wrap;">
    {{if eq $app.Status "运行中"}}
    <form action="/stop/{{$name}}" method="post" style="display:inline;"><button class="btn btn-warning btn-sm"><i class="fa-solid fa-stop"></i></button></form>
    <form action="/restart/{{$name}}" method="post" style="display:inline;"><button class="btn btn-primary btn-sm"><i class="fa-solid fa-rotate"></i></button></form>
    {{else}}
    <form action="/start/{{$name}}" method="post" style="display:inline;"><button class="btn btn-success btn-sm"><i class="fa-solid fa-play"></i></button></form>
    {{end}}
    <a href="/edit/{{$name}}" class="btn btn-ghost btn-sm"><i class="fa-solid fa-pen"></i></a>
    <a href="/log/{{$name}}" class="btn btn-ghost btn-sm"><i class="fa-solid fa-file-lines"></i></a>
    <form action="/toggle-auto/{{$name}}" method="post" style="display:inline;"><button class="btn btn-ghost btn-sm" title="切换自启"><i class="fa-solid fa-rotate"></i></button></form>
    <form action="/delete/{{$name}}" method="post" style="display:inline;" onsubmit="return confirm('确定删除 {{$name}}？\n沙盒: {{$app.Path}}{{if $app.WorkDir}}\n外部: {{$app.WorkDir}}{{end}}\n（仅清理沙盒目录）')"><button class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></button></form>
  </div>
</div>
{{end}}

{{if eq (len .Apps) 0}}
<div class="glass" style="padding:3rem;text-align:center;">
  <i class="fa-solid fa-inbox" style="font-size:3rem;color:rgba(255,255,255,0.15);margin-bottom:1rem;"></i>
  <p style="color:var(--text-dim);">暂无应用，请创建或从商店部署</p>
</div>
{{end}}
</div>
<script>
(function(){var b=document.getElementById('themeBtn');if(!b)return;var s=localStorage.getItem('lp_theme');if(s==='light'){document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';}b.addEventListener('click',function(){var c=document.documentElement.getAttribute('data-theme');if(c==='light'){document.documentElement.removeAttribute('data-theme');b.innerHTML='<i class="fa-solid fa-moon"></i>';localStorage.setItem('lp_theme','dark');}else{document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';localStorage.setItem('lp_theme','light');}});})();
(function(){
var form=document.getElementById('createForm');
var prog=document.getElementById('createProgress');
var fill=document.getElementById('progressFill');
var text=document.getElementById('progressText');
var btn=document.getElementById('createBtn');
var banner=document.getElementById('activeTaskBanner');
var bannerMsg=document.getElementById('activeTaskMsg');
var bannerFill=document.getElementById('activeTaskFill');
if(!form)return;
var pollId=null;
var activeTaskId=localStorage.getItem('lp_createTask');
var activeTaskErr=localStorage.getItem('lp_createErr');

function showBanner(){
  if(banner){banner.style.display='block';}
}
function hideBanner(){
  if(banner){banner.style.display='none';}
  localStorage.removeItem('lp_createTask');
  localStorage.removeItem('lp_createErr');
}

function pollProgress(id){
  fetch('/create/progress/'+id).then(function(r){return r.json();}).then(function(t){
    if(!t||!t.status){return;}
    if(t.status==='creating'||t.status==='downloading'){
      var pct=t.progress||0;
      if(fill)fill.style.width=pct+'%';
      if(text)text.textContent=t.message||'处理中... '+pct+'%';
      if(bannerMsg)bannerMsg.textContent=t.message||'正在创建...';
      if(bannerFill)bannerFill.style.width=pct+'%';
      showBanner();
      pollId=setTimeout(function(){pollProgress(id);},500);
    }else if(t.status==='completed'){
      if(fill)fill.style.width='100%';
      if(text)text.textContent='创建完成！';
      if(bannerFill)bannerFill.style.width='100%';
      if(bannerMsg)bannerMsg.textContent='创建完成！';
      showBanner();
      clearTimeout(pollId);
      hideBanner();
      setTimeout(function(){location.reload();},600);
    }else if(t.status==='error'){
      if(text){text.textContent='错误: '+t.message;text.style.color='#f87171';}
      if(bannerMsg)bannerMsg.textContent='创建失败: '+t.message;
      if(bannerFill)bannerFill.style.width='100%';
      if(banner)banner.style.borderColor='rgba(239,68,68,0.3)';
      showBanner();
      btn.disabled=false;
      btn.innerHTML='<i class="fa-solid fa-plus"></i>创建应用';
      clearTimeout(pollId);
      localStorage.setItem('lp_createErr','1');
      localStorage.removeItem('lp_createTask');
    }else if(t.status==='not_found'){
      hideBanner();
    }
  }).catch(function(){
    pollId=setTimeout(function(){pollProgress(id);},1000);
  });
}

if(activeTaskErr){
  if(banner){
    banner.style.display='block';
    banner.style.borderColor='rgba(239,68,68,0.3)';
    bannerMsg.textContent='上次创建失败，请检查输入后重试';
    bannerFill.style.width='100%';
  }
  localStorage.removeItem('lp_createErr');
}

if(activeTaskId){
  pollProgress(activeTaskId);
}

form.addEventListener('submit',function(e){
  e.preventDefault();
  var nameEl=document.getElementById('appName');
  var cmdEl=document.getElementById('appCmd');
  if(!nameEl||!cmdEl){console.error('[LP] Form elements not found');return;}
  var name=nameEl.value.trim();
  var cmd=cmdEl.value.trim();
  console.log('[LP] submit - name:',JSON.stringify(name),'cmd:',JSON.stringify(cmd));
  if(!name||!cmd){
    if(!name)nameEl.focus();
    if(!cmd)cmdEl.focus();
    return;
  }
  localStorage.removeItem('lp_createErr');
  btn.disabled=true;
  btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i>创建中...';
  prog.style.display='block';
  fill.style.width='5%';
  text.textContent='准备创建...';
  var fd=new FormData(form);
  console.log('[LP] FormData entries:');
  for(var p of fd.entries()){console.log('  ',p[0],':',p[1]);}
  fetch('/create',{method:'POST',body:fd}).then(function(r){
    var ct=r.headers.get('content-type')||'';
    if(ct.indexOf('json')===-1){
      console.error('[LP] Expected JSON, got',ct,'- URL:',r.url,'- Status:',r.status);
      text.textContent='请求失败，请刷新重试';
      btn.disabled=false;
      btn.innerHTML='<i class="fa-solid fa-plus"></i>创建应用';
      return;
    }
    return r.json();
  }).then(function(data){
    if(!data){return;}
    console.log('[LP] create response:',data);
    if(data.ok&&data.task){
      localStorage.setItem('lp_createTask',data.task);
      pollProgress(data.task);
      setTimeout(function(){window.location.replace(data.redirect||'/');},300);
    }else if(data.error){
      text.textContent=data.error;
      text.style.color='#f87171';
      if(bannerMsg)bannerMsg.textContent='创建失败: '+data.error;
      if(banner)banner.style.borderColor='rgba(239,68,68,0.3)';
      showBanner();
      localStorage.setItem('lp_createErr','1');
      btn.disabled=false;
      btn.innerHTML='<i class="fa-solid fa-plus"></i>创建应用';
    }
  }).catch(function(err){
    console.error('[LP] fetch error:',err);
    text.textContent='网络错误，请刷新重试';
    btn.disabled=false;
    btn.innerHTML='<i class="fa-solid fa-plus"></i>创建应用';
  });
});
})();
</script>
</body>
</html>`

const htmlStore = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>应用商店 - LightPanel</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
* { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',system-ui,sans-serif; }
body { background:var(--bg); min-height:100vh; position:relative; }
.bg-layer { position:fixed; inset:0; z-index:0; background:radial-gradient(ellipse at 50% 30%,rgba(168,85,247,0.15) 0%,transparent 60%),var(--bg); }
.container { position:relative; z-index:1; max-width:900px; margin:0 auto; padding:1.5rem; }
.glass-card { background:var(--bg-card); backdrop-filter:blur(20px) saturate(180%); border:1px solid var(--border); border-radius:16px; padding:1.25rem; transition:all 0.3s ease; }
.glass-card:hover { background:var(--bg-glass); border-color:var(--border); transform:translateY(-2px); }
.btn { display:inline-flex; align-items:center; justify-content:center; gap:0.5rem; padding:0.6rem 1.2rem; border-radius:12px; font-size:0.875rem; font-weight:500; transition:all 0.2s ease; cursor:pointer; border:none; text-decoration:none; }
.btn-primary { background:linear-gradient(135deg,#6366f1,#7c3aed); color:#fff; }
.btn-primary:hover { box-shadow:0 4px 20px rgba(99,102,241,0.4); }
.btn-success { background:linear-gradient(135deg,#10b981,#059669); color:#fff; }
.btn-ghost { background:var(--bg-glass); color:var(--text); border:1px solid var(--border); backdrop-filter:blur(12px); }
.btn-ghost:hover { background:var(--border); color:var(--text); }
.btn:disabled { opacity:0.5; cursor:not-allowed; }
.source-tabs { display:flex; gap:0.5rem; margin-bottom:1.5rem; flex-wrap:wrap; }
.source-tab { padding:0.5rem 1rem; border-radius:10px; font-size:0.8rem; transition:all 0.2s; text-decoration:none; }
.source-tab.active { background:linear-gradient(135deg,#6366f1,#7c3aed); color:#fff; }
.source-tab:not(.active) { background:rgba(255,255,255,0.05); color:var(--text-dim); border:1px solid rgba(255,255,255,0.08); }
.store-item { display:flex; align-items:center; gap:1rem; }
.store-icon { width:56px; height:56px; border-radius:14px; object-fit:cover; border:2px solid rgba(255,255,255,0.1); }
.overlay { position:fixed; inset:0; z-index:9998; background:rgba(0,0,0,0.6); backdrop-filter:blur(4px); display:flex; align-items:center; justify-content:center; }
.overlay-box { background:#1a1a2e; border:1px solid rgba(255,255,255,0.1); border-radius:20px; padding:2rem; max-width:400px; width:90%; text-align:center; }
@keyframes spin { to { transform:rotate(360deg); } }
.spinner { width:32px; height:32px; border:3px solid rgba(255,255,255,0.1); border-top-color:#10b981; border-radius:50%; animation:spin 0.8s linear infinite; margin:0 auto 1rem; }
@keyframes toast-in { from { transform:translateX(100%); opacity:0; } to { transform:translateX(0); opacity:1; } }
@keyframes toast-out { from { transform:translateX(0); opacity:1; } to { transform:translateX(100%); opacity:0; } }
.toast { position:fixed; top:1.5rem; right:1.5rem; z-index:9999; padding:0.85rem 1.25rem; border-radius:12px; font-size:0.85rem; font-weight:500; color:#fff; max-width:380px; box-shadow:0 8px 32px rgba(0,0,0,0.5); animation:toast-in 0.3s ease; }
.toast-success { background:linear-gradient(135deg,#10b981,#059669); }
.toast-error { background:linear-gradient(135deg,#ef4444,#dc2626); }
</style>
</head>
<body>
<div class="bg-layer"></div>
<div class="container">
<div style="display:flex;align-items:center;gap:1rem;margin-bottom:2rem;">
  <a href="/" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i>返回</a>
  <a href="/source" class="btn btn-ghost"><i class="fa-solid fa-database"></i>源管理</a>
  <h1 style="font-size:1.5rem;font-weight:700;color:var(--text);margin-left:auto;"><i class="fa-solid fa-store" style="color:#a855f7;margin-right:0.5rem;"></i>应用商店</h1>
  <button id="themeBtn" class="btn btn-ghost" title="切换主题"><i class="fa-solid fa-moon"></i></button>
  <a href="/logout" class="btn btn-ghost" style="color:#f87171;" title="退出"><i class="fa-solid fa-right-from-bracket"></i></a>
</div>
<div class="source-tabs">
{{range $i,$s := .Sources}}
{{if eq $i $.Active}}
<span class="source-tab active">{{$s.Name}}</span>
{{else}}
<a href="/store?source={{$i}}" class="source-tab">{{$s.Name}}</a>
{{end}}
{{end}}
</div>
<div style="display:grid;gap:1rem;">
{{range $i,$a := .Apps}}
<div class="glass-card store-item">
  <img src="{{$a.Icon}}" class="store-icon" referrerpolicy="no-referrer" onerror="this.style.display='none'">
  <div style="flex:1;">
      <h3 style="font-size:1.05rem;font-weight:600;color:var(--text);">{{$a.Name}}</h3>
    <p style="font-size:0.8rem;color:var(--text-dim);margin-top:0.25rem;">{{$a.Desc}}</p>
    <p style="font-size:0.7rem;color:var(--text-dim);margin-top:0.35rem;"><i class="fa-solid fa-user" style="margin-right:0.3rem;"></i>{{$a.Author}}</p>
  </div>
  <form action="/install/{{$i}}?source={{$.Active}}" method="post" style="display:inline;" class="install-form">
    <button class="btn btn-success"><i class="fa-solid fa-download"></i>部署</button>
  </form>
</div>
{{end}}
</div>
</div>

<script>
(function(){var b=document.getElementById('themeBtn');if(!b)return;var s=localStorage.getItem('lp_theme');if(s==='light'){document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';}b.addEventListener('click',function(){var c=document.documentElement.getAttribute('data-theme');if(c==='light'){document.documentElement.removeAttribute('data-theme');b.innerHTML='<i class="fa-solid fa-moon"></i>';localStorage.setItem('lp_theme','dark');}else{document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';localStorage.setItem('lp_theme','light');}});})();
document.querySelectorAll('.install-form').forEach(function(form) {
  form.addEventListener('submit', function(e) {
    var btn = form.querySelector('button');
    if (btn && btn.disabled) { e.preventDefault(); return; }
  });
});
</script>
</body>
</html>`

const htmlDownloads = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>下载管理 - LightPanel</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
:root { --accent:#6366f1; --bg:#0f0f23; --bg-card:rgba(255,255,255,0.03); --bg-glass:rgba(255,255,255,0.05); --text:#fff; --text-dim:rgba(255,255,255,0.4); --border:rgba(255,255,255,0.08); }
[data-theme="light"] { --bg:#f0f2f5; --bg-card:#fff; --bg-glass:rgba(0,0,0,0.03); --text:#1a1a2e; --text-dim:rgba(0,0,0,0.4); --border:rgba(0,0,0,0.08); }
* { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',system-ui,sans-serif; }
body { background:var(--bg); min-height:100vh; position:relative; }
.bg-layer { position:fixed; inset:0; z-index:0; background:radial-gradient(ellipse at 50% 50%,rgba(99,102,241,0.1) 0%,transparent 60%),var(--bg); }
.container { position:relative; z-index:1; max-width:900px; margin:0 auto; padding:1.5rem; }
.glass { background:var(--bg-card); backdrop-filter:blur(20px) saturate(180%); border:1px solid var(--border); border-radius:16px; }
.glass-card { background:var(--bg-card); backdrop-filter:blur(20px) saturate(180%); border:1px solid var(--border); border-radius:16px; padding:1.25rem; margin-bottom:0.75rem; }
.btn { display:inline-flex; align-items:center; justify-content:center; gap:0.5rem; padding:0.5rem 1rem; border-radius:10px; font-size:0.8rem; font-weight:500; transition:all 0.2s ease; cursor:pointer; border:none; text-decoration:none; }
.btn-ghost { background:var(--bg-glass); color:var(--text); border:1px solid var(--border); backdrop-filter:blur(12px); }
.btn-ghost:hover { background:var(--border); color:var(--text); }
.btn-success { background:linear-gradient(135deg,#10b981,#059669); color:#fff; }
.btn-warning { background:linear-gradient(135deg,#f59e0b,#d97706); color:#fff; }
.btn-danger { background:linear-gradient(135deg,#ef4444,#dc2626); color:#fff; }
.btn-info { background:linear-gradient(135deg,#3b82f6,#2563eb); color:#fff; }
.btn:disabled { opacity:0.4; cursor:not-allowed; }
.badge { display:inline-block; padding:0.2rem 0.6rem; border-radius:6px; font-size:0.7rem; font-weight:500; }
.badge-downloading { background:rgba(59,130,246,0.15); color:#60a5fa; border:1px solid rgba(59,130,246,0.3); }
.badge-paused { background:rgba(245,158,11,0.15); color:#fbbf24; border:1px solid rgba(245,158,11,0.3); }
.badge-completed { background:rgba(16,185,129,0.15); color:#34d399; border:1px solid rgba(16,185,129,0.3); }
.badge-error { background:rgba(239,68,68,0.15); color:#f87171; border:1px solid rgba(239,68,68,0.3); }
.progress-bar { width:100%; height:8px; background:rgba(255,255,255,0.08); border-radius:4px; overflow:hidden; margin:0.5rem 0; }
.progress-fill { height:100%; background:linear-gradient(90deg,#6366f1,#a855f7); border-radius:4px; transition:width 0.5s ease; }
</style>
</head>
<body>
<div class="bg-layer"></div>
<div class="container">
<div style="display:flex;align-items:center;gap:1rem;margin-bottom:2rem;">
  <a href="/" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i>返回</a>
  <h1 style="font-size:1.5rem;font-weight:700;color:var(--text);margin-left:auto;"><i class="fa-solid fa-download" style="color:#6366f1;margin-right:0.5rem;"></i>下载管理</h1>
  <button id="themeBtn" class="btn btn-ghost" title="切换主题"><i class="fa-solid fa-moon"></i></button>
  <a href="/logout" class="btn btn-ghost" style="color:#f87171;" title="退出"><i class="fa-solid fa-right-from-bracket"></i></a>
</div>

<div id="taskList">
{{range .}}
<div class="glass-card" id="task-{{.ID}}">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.5rem;">
    <div>
      <span style="font-size:1rem;font-weight:600;color:var(--text);">{{.Name}}</span>
      <span class="badge badge-{{.Status}}" style="margin-left:0.5rem;">
        {{if eq .Status "downloading"}}下载中{{end}}
        {{if eq .Status "paused"}}已暂停{{end}}
        {{if eq .Status "completed"}}已完成{{end}}
        {{if eq .Status "error"}}失败{{end}}
      </span>
    </div>
    <div style="display:flex;gap:0.4rem;">
      {{if eq .Status "downloading"}}
      <button class="btn btn-warning" onclick="dlAction('{{.ID}}','pause')"><i class="fa-solid fa-pause"></i>暂停</button>
      {{end}}
      {{if eq .Status "paused"}}
      <button class="btn btn-success" onclick="dlAction('{{.ID}}','resume')"><i class="fa-solid fa-play"></i>继续</button>
      {{end}}
      {{if eq .Status "completed"}}
      <button class="btn btn-info" onclick="dlAction('{{.ID}}','install')"><i class="fa-solid fa-rocket"></i>安装</button>
      {{end}}
      <button class="btn btn-danger" onclick="dlAction('{{.ID}}','delete')"><i class="fa-solid fa-trash"></i></button>
    </div>
  </div>
  <div style="font-size:0.75rem;color:var(--text-dim);word-break:break-all;margin-bottom:0.3rem;">{{.URL}}</div>
  <div class="progress-bar"><div class="progress-fill" style="width:{{.Progress}}%"></div></div>
  <div style="font-size:0.75rem;color:var(--text-dim);display:flex;justify-content:space-between;">
    <span>{{.Progress}}%</span>
    <span>{{formatSize .Downloaded}} / {{formatSize .Size}}</span>
  </div>
</div>
{{end}}
{{if eq (len .) 0}}
<div class="glass" style="padding:3rem;text-align:center;">
  <i class="fa-solid fa-inbox" style="font-size:3rem;color:rgba(255,255,255,0.15);margin-bottom:1rem;"></i>
  <p style="color:var(--text-dim);">暂无下载任务</p>
</div>
{{end}}
</div>
</div>
</div>
<script>
function formatSize(b) {
  if (b <= 0) return '0 B';
  var u = ['B','KB','MB','GB','TB'];
  var i = 0;
  while (b >= 1024 && i < u.length-1) { b /= 1024; i++; }
  return b.toFixed(1) + ' ' + u[i];
}
function dlAction(id, act) {
  fetch('/dl/action/' + id + '/' + act, { method: 'POST' })
    .then(function() { location.reload(); });
}
setInterval(function() {
  fetch('/dl/api')
    .then(function(r) { return r.json(); })
    .then(function(tasks) {
      tasks.forEach(function(t) {
        var card = document.getElementById('task-' + t.id);
        if (!card) return;
        var fill = card.querySelector('.progress-fill');
        if (fill) fill.style.width = t.progress + '%';
      });
    });
}, 1000);
(function(){var b=document.getElementById('themeBtn');if(!b)return;var s=localStorage.getItem('lp_theme');if(s==='light'){document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';}b.addEventListener('click',function(){var c=document.documentElement.getAttribute('data-theme');if(c==='light'){document.documentElement.removeAttribute('data-theme');b.innerHTML='<i class="fa-solid fa-moon"></i>';localStorage.setItem('lp_theme','dark');}else{document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';localStorage.setItem('lp_theme','light');}});})();
</script>
</body>
</html>`

const htmlEdit = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>编辑应用 - LightPanel</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
:root { --accent:#6366f1; --accent-glow:rgba(99,102,241,0.4); --bg:#0f0f23; --bg-card:rgba(255,255,255,0.06); --bg-glass:rgba(255,255,255,0.08); --text:#fff; --text-dim:rgba(255,255,255,0.4); --border:rgba(255,255,255,0.1); --input-bg:rgba(255,255,255,0.06); --input-border:rgba(255,255,255,0.12); --input-text:#fff; --input-ph:rgba(255,255,255,0.3); }
[data-theme="light"] { --bg:#e8eaed; --bg-card:rgba(255,255,255,0.85); --bg-glass:rgba(255,255,255,0.6); --text:#1a1a2e; --text-dim:rgba(0,0,0,0.5); --border:rgba(0,0,0,0.1); --input-bg:rgba(255,255,255,0.9); --input-border:rgba(0,0,0,0.15); --input-text:#1a1a2e; --input-ph:rgba(0,0,0,0.35); }
* { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',system-ui,sans-serif; }
body { background:var(--bg); min-height:100vh; position:relative; }
.bg-layer { position:fixed; inset:0; z-index:0; background:radial-gradient(ellipse at 50% 50%,rgba(99,102,241,0.12) 0%,transparent 60%),var(--bg); }
.container { position:relative; z-index:1; max-width:600px; margin:0 auto; padding:1.5rem; }
.glass { background:var(--bg-card); backdrop-filter:blur(20px) saturate(180%); border:1px solid var(--border); border-radius:16px; }
.btn { display:inline-flex; align-items:center; justify-content:center; gap:0.5rem; padding:0.6rem 1.2rem; border-radius:12px; font-size:0.875rem; font-weight:500; transition:all 0.2s ease; cursor:pointer; border:none; text-decoration:none; }
.btn-primary { background:linear-gradient(135deg,#6366f1,#7c3aed); color:#fff; }
.btn-primary:hover { box-shadow:0 4px 20px rgba(99,102,241,0.4); }
.btn-ghost { background:var(--bg-glass); color:var(--text); border:1px solid var(--border); backdrop-filter:blur(12px); }
.btn-ghost:hover { background:var(--border); color:var(--text); }
.input { width:100%; padding:0.75rem 1rem; border-radius:12px; background:var(--input-bg); border:1px solid var(--input-border); color:var(--input-text); font-size:0.875rem; }
.input:focus { outline:none; border-color:#6366f1; box-shadow:0 0 0 3px rgba(99,102,241,0.3); }
.input::placeholder { color:var(--input-ph); }
.alert { padding:0.75rem 1rem; border-radius:10px; font-size:0.85rem; margin-bottom:1rem; }
.alert-error { background:rgba(239,68,68,0.15); color:#f87171; border:1px solid rgba(239,68,68,0.3); }
.alert-success { background:rgba(16,185,129,0.15); color:#34d399; border:1px solid rgba(16,185,129,0.3); }
.badge { display:inline-flex; align-items:center; gap:0.35rem; padding:0.3rem 0.75rem; border-radius:9999px; font-size:0.75rem; font-weight:500; }
.badge-running { background:rgba(16,185,129,0.15); color:#34d399; border:1px solid rgba(16,185,129,0.3); }
.badge-stopped { background:rgba(239,68,68,0.15); color:#f87171; border:1px solid rgba(239,68,68,0.3); }
.check-label { display:flex; align-items:center; gap:0.5rem; padding:0.75rem 1rem; border-radius:12px; background:var(--bg-glass); border:1px solid var(--border); cursor:pointer; transition:all 0.2s; }
.check-label:has(input:checked) { background:rgba(16,185,129,0.1); border-color:rgba(16,185,129,0.3); }
.check-label input { display:none; }
.check-box { width:20px; height:20px; border-radius:6px; border:2px solid var(--input-border); display:flex; align-items:center; justify-content:center; transition:all 0.2s; }
.check-label:has(input:checked) .check-box { background:#10b981; border-color:#10b981; }
</style>
</head>
<body>
<div class="bg-layer"></div>
<div class="container">
<div style="display:flex;align-items:center;gap:1rem;margin-bottom:2rem;">
  <a href="/" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i>返回</a>
  <h1 style="font-size:1.5rem;font-weight:700;color:var(--text);margin-left:auto;"><i class="fa-solid fa-pen-to-square" style="color:#6366f1;margin-right:0.5rem;"></i>编辑应用</h1>
  <button id="themeBtn" class="btn btn-ghost" title="切换主题"><i class="fa-solid fa-moon"></i></button>
  <a href="/logout" class="btn btn-ghost" style="color:#f87171;" title="退出"><i class="fa-solid fa-right-from-bracket"></i></a>
</div>

{{if eq .Err "running"}}
<div class="alert alert-error"><i class="fa-solid fa-triangle-exclamation" style="margin-right:0.5rem;"></i>请先停止应用后再编辑</div>
{{end}}
{{if eq .Err "exists"}}
<div class="alert alert-error"><i class="fa-solid fa-triangle-exclamation" style="margin-right:0.5rem;"></i>新名称已存在</div>
{{end}}
{{if eq .Err "rename"}}
<div class="alert alert-error"><i class="fa-solid fa-triangle-exclamation" style="margin-right:0.5rem;"></i>重命名失败，请检查权限</div>
{{end}}
{{if eq .Err "save"}}
<div class="alert alert-error"><i class="fa-solid fa-triangle-exclamation" style="margin-right:0.5rem;"></i>保存配置失败</div>
{{end}}
{{if eq .Msg "1"}}
<div class="alert alert-success"><i class="fa-solid fa-check" style="margin-right:0.5rem;"></i>已保存</div>
{{end}}
{{if .InstallNote}}
<div class="alert" style="background:rgba(99,102,241,0.12);color:#a5b4fc;border:1px solid rgba(99,102,241,0.3);"><i class="fa-solid fa-circle-info" style="margin-right:0.5rem;"></i>安装检测: {{.InstallNote}} <a href="/detect/{{.Name}}" style="color:#818cf8;margin-left:0.5rem;cursor:pointer;">[重新检测]</a></div>
{{end}}

<div class="glass" style="padding:1.5rem;">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;">
    <h3 style="font-size:1.1rem;font-weight:600;color:var(--text);">{{.Name}}</h3>
    {{if eq .Status "运行中"}}
    <span class="badge badge-running"><span style="width:6px;height:6px;background:#34d399;border-radius:50%;"></span>运行中</span>
    {{else}}
    <span class="badge badge-stopped"><span style="width:6px;height:6px;background:#f87171;border-radius:50%;"></span>已停止</span>
    {{end}}
  </div>

  <form id="editForm" action="/edit/{{.Name}}" method="post" style="display:grid;gap:0.75rem;">
    <div>
      <label style="font-size:0.75rem;color:var(--text-dim);margin-bottom:0.35rem;display:block;">应用名称（修改将重命名沙盒目录）</label>
      <input name="name" value="{{.Name}}" required class="input">
    </div>
    <div>
      <label style="font-size:0.75rem;color:var(--text-dim);margin-bottom:0.35rem;display:block;">沙盒路径</label>
      <input name="path" value="{{.Path}}" placeholder="留空不修改" class="input">
    </div>
    <div>
      <label style="font-size:0.75rem;color:var(--text-dim);margin-bottom:0.35rem;display:block;">工作目录（留空则使用沙盒路径，脚本安装会自动检测）</label>
      <input name="work_dir" value="{{.WorkDir}}" placeholder="如 /opt/komari 或 /usr/local/bin" class="input">
    </div>
    <div>
      <label style="font-size:0.75rem;color:var(--text-dim);margin-bottom:0.35rem;display:block;">首次运行命令（仅执行一次，如 apt install）</label>
      <input name="setup_cmd" value="{{.SetupCmd}}" placeholder="留空则不执行" class="input">
    </div>
    <div>
      <label style="font-size:0.75rem;color:var(--text-dim);margin-bottom:0.35rem;display:block;">启动命令</label>
      <input name="cmd" value="{{.Cmd}}" required class="input">
    </div>
    <label class="check-label">
      <input type="checkbox" name="auto"{{if .Auto}} checked{{end}}>
      <div class="check-box"><i class="fa-solid fa-check" style="font-size:0.7rem;color:#fff;"></i></div>
      <span style="color:var(--text-dim);font-size:0.875rem;">开机自启（面板重启后自动启动此应用，崩溃自动重启）</span>
    </label>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;margin-top:0.5rem;">
      <button class="btn btn-primary" style="width:100%;"><i class="fa-solid fa-save"></i>保存</button>
      <a href="/" class="btn btn-ghost" style="width:100%;"><i class="fa-solid fa-xmark"></i>取消</a>
    </div>
  </form>
</div>

<div style="font-size:0.75rem;color:var(--text-dim);margin-top:1rem;text-align:center;">
  <i class="fa-solid fa-clock" style="margin-right:0.3rem;"></i>创建时间：{{.Created}}
  {{if .SourceURL}}<br><i class="fa-solid fa-link" style="margin-right:0.3rem;"></i>来源：<a href="{{.SourceURL}}" target="_blank" style="color:#60a5fa;text-decoration:none;">{{.SourceURL}}</a>{{end}}
</div>
</div>
<script>
(function(){var b=document.getElementById('themeBtn');if(!b)return;var s=localStorage.getItem('lp_theme');if(s==='light'){document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';}b.addEventListener('click',function(){var c=document.documentElement.getAttribute('data-theme');if(c==='light'){document.documentElement.removeAttribute('data-theme');b.innerHTML='<i class="fa-solid fa-moon"></i>';localStorage.setItem('lp_theme','dark');}else{document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';localStorage.setItem('lp_theme','light');}});})();
</script>
</body>
</html>`

const htmlSource = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>源管理 - LightPanel</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
:root { --accent:#10b981; --bg:#0f0f23; --bg-card:rgba(255,255,255,0.03); --bg-glass:rgba(255,255,255,0.05); --text:#fff; --text-dim:rgba(255,255,255,0.4); --border:rgba(255,255,255,0.08); --input-bg:rgba(255,255,255,0.05); --input-border:rgba(255,255,255,0.1); --input-text:#fff; --input-ph:rgba(255,255,255,0.3); }
[data-theme="light"] { --bg:#e8eaed; --bg-card:rgba(255,255,255,0.85); --bg-glass:rgba(255,255,255,0.6); --text:#1a1a2e; --text-dim:rgba(0,0,0,0.5); --border:rgba(0,0,0,0.1); --input-bg:rgba(255,255,255,0.9); --input-border:rgba(0,0,0,0.15); --input-text:#1a1a2e; --input-ph:rgba(0,0,0,0.35); }
* { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',system-ui,sans-serif; }
body { background:var(--bg); min-height:100vh; position:relative; }
.bg-layer { position:fixed; inset:0; z-index:0; background:radial-gradient(ellipse at 70% 60%,rgba(16,185,129,0.12) 0%,transparent 60%),var(--bg); }
.container { position:relative; z-index:1; max-width:700px; margin:0 auto; padding:1.5rem; }
.glass { background:var(--bg-card); backdrop-filter:blur(20px) saturate(180%); border:1px solid var(--border); border-radius:16px; }
.glass-card { background:var(--bg-card); backdrop-filter:blur(20px) saturate(180%); border:1px solid var(--border); border-radius:16px; padding:1.25rem; display:flex; justify-content:space-between; align-items:center; transition:all 0.3s ease; }
.glass-card:hover { background:var(--bg-glass); }
.btn { display:inline-flex; align-items:center; justify-content:center; gap:0.5rem; padding:0.6rem 1.2rem; border-radius:12px; font-size:0.875rem; font-weight:500; transition:all 0.2s ease; cursor:pointer; border:none; text-decoration:none; }
.btn-primary { background:linear-gradient(135deg,#10b981,#059669); color:#fff; }
.btn-danger { background:linear-gradient(135deg,#ef4444,#dc2626); color:#fff; }
.btn-ghost { background:var(--bg-glass); color:var(--text); border:1px solid var(--border); backdrop-filter:blur(12px); }
.btn-ghost:hover { background:var(--border); color:var(--text); }
.input { width:100%; padding:0.75rem 1rem; border-radius:12px; background:var(--input-bg); border:1px solid var(--input-border); color:var(--input-text); font-size:0.875rem; }
.input:focus { outline:none; border-color:#10b981; box-shadow:0 0 0 3px rgba(16,185,129,0.3); }
.input::placeholder { color:var(--input-ph); }
</style>
</head>
<body>
<div class="bg-layer"></div>
<div class="container">
<div style="display:flex;align-items:center;gap:1rem;margin-bottom:2rem;">
  <a href="/" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i>返回</a>
  <h1 style="font-size:1.5rem;font-weight:700;color:var(--text);margin-left:auto;"><i class="fa-solid fa-database" style="color:#10b981;margin-right:0.5rem;"></i>商店源管理</h1>
  <button id="themeBtn" class="btn btn-ghost" title="切换主题"><i class="fa-solid fa-moon"></i></button>
  <a href="/logout" class="btn btn-ghost" style="color:#f87171;" title="退出"><i class="fa-solid fa-right-from-bracket"></i></a>
</div>
<div class="glass" style="padding:1.5rem;margin-bottom:1.5rem;">
  <h3 style="font-size:1rem;font-weight:600;color:var(--text);margin-bottom:1rem;"><i class="fa-solid fa-plus" style="color:#10b981;margin-right:0.5rem;"></i>添加源</h3>
  <form action="/source/add" method="post" style="display:grid;grid-template-columns:1fr 2fr auto;gap:0.75rem;align-items:end;">
    <input name="name" placeholder="源名称" required class="input">
    <input name="url" placeholder="JSON 地址" required class="input">
    <button class="btn btn-primary" style="height:44px;"><i class="fa-solid fa-plus"></i>添加</button>
  </form>
</div>
<div style="display:grid;gap:0.75rem;">
{{range $i,$s := .}}
<div class="glass-card">
  <div>
    <p style="font-weight:600;color:var(--text);">{{$s.Name}}</p>
    <p style="font-size:0.75rem;color:var(--text-dim);margin-top:0.25rem;word-break:break-all;">{{$s.URL}}</p>
  </div>
  <form action="/source/del/{{$i}}" method="post" style="display:inline;"><button class="btn btn-danger" onclick="return confirm('删除此源？')"><i class="fa-solid fa-trash"></i></button></form>
</div>
{{end}}
</div>
</div>
<script>
(function(){var b=document.getElementById('themeBtn');if(!b)return;var s=localStorage.getItem('lp_theme');if(s==='light'){document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';}b.addEventListener('click',function(){var c=document.documentElement.getAttribute('data-theme');if(c==='light'){document.documentElement.removeAttribute('data-theme');b.innerHTML='<i class="fa-solid fa-moon"></i>';localStorage.setItem('lp_theme','dark');}else{document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';localStorage.setItem('lp_theme','light');}});})();
</script>
</body>
</html>`

const htmlSetting = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>设置 - LightPanel</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
:root { --accent:#f59e0b; --bg:#0f0f23; --bg-card:rgba(255,255,255,0.03); --bg-glass:rgba(255,255,255,0.05); --text:#fff; --text-dim:rgba(255,255,255,0.4); --border:rgba(255,255,255,0.08); --input-bg:rgba(255,255,255,0.05); --input-border:rgba(255,255,255,0.1); --input-text:#fff; --input-ph:rgba(255,255,255,0.3); }
[data-theme="light"] { --bg:#e8eaed; --bg-card:rgba(255,255,255,0.85); --bg-glass:rgba(255,255,255,0.6); --text:#1a1a2e; --text-dim:rgba(0,0,0,0.5); --border:rgba(0,0,0,0.1); --input-bg:rgba(255,255,255,0.9); --input-border:rgba(0,0,0,0.15); --input-text:#1a1a2e; --input-ph:rgba(0,0,0,0.35); }
* { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',system-ui,sans-serif; }
body { background:var(--bg); min-height:100vh; position:relative; }
.bg-layer { position:fixed; inset:0; z-index:0; background:radial-gradient(ellipse at 30% 70%,rgba(245,158,11,0.12) 0%,transparent 60%),var(--bg); }
.container { position:relative; z-index:1; max-width:550px; margin:0 auto; padding:1.5rem; }
.glass { background:var(--bg-card); backdrop-filter:blur(20px) saturate(180%); border:1px solid var(--border); border-radius:16px; }
.btn { display:inline-flex; align-items:center; justify-content:center; gap:0.5rem; padding:0.6rem 1.2rem; border-radius:12px; font-size:0.875rem; font-weight:500; transition:all 0.2s ease; cursor:pointer; border:none; text-decoration:none; }
.btn-primary { background:linear-gradient(135deg,#f59e0b,#d97706); color:#fff; }
.btn-ghost { background:var(--bg-glass); color:var(--text); border:1px solid var(--border); backdrop-filter:blur(12px); }
.btn-ghost:hover { background:var(--border); color:var(--text); }
.input { width:100%; padding:0.75rem 1rem; border-radius:12px; background:var(--input-bg); border:1px solid var(--input-border); color:var(--input-text); font-size:0.875rem; }
.input:focus { outline:none; border-color:#f59e0b; box-shadow:0 0 0 3px rgba(245,158,11,0.3); }
.input::placeholder { color:var(--input-ph); }
.alert { padding:0.75rem 1rem; border-radius:10px; font-size:0.85rem; margin-bottom:1rem; }
.alert-success { background:rgba(16,185,129,0.15); color:#34d399; border:1px solid rgba(16,185,129,0.3); }
.alert-error { background:rgba(239,68,68,0.15); color:#f87171; border:1px solid rgba(239,68,68,0.3); }
.radio-group { display:flex; gap:0.75rem; margin-bottom:0.75rem; }
.radio-label { display:flex; align-items:center; gap:0.4rem; padding:0.5rem 1rem; border-radius:10px; cursor:pointer; font-size:0.85rem; transition:all 0.2s; border:1px solid var(--border); color:var(--text-dim); }
.radio-label:has(input:checked) { background:rgba(245,158,11,0.15); border-color:rgba(245,158,11,0.4); color:#fbbf24; }
.radio-label input { display:none; }
</style>
</head>
<body>
<div class="bg-layer"></div>
<div class="container">
<div style="display:flex;align-items:center;gap:1rem;margin-bottom:2rem;">
  <a href="/" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i>返回</a>
  <h1 style="font-size:1.5rem;font-weight:700;color:var(--text);margin-left:auto;"><i class="fa-solid fa-gear" style="color:#f59e0b;margin-right:0.5rem;"></i>设置</h1>
  <button id="themeBtn" class="btn btn-ghost" title="切换主题"><i class="fa-solid fa-moon"></i></button>
  <a href="/logout" class="btn btn-ghost" style="color:#f87171;" title="退出"><i class="fa-solid fa-right-from-bracket"></i></a>
</div>

{{if eq .Msg "1"}}
<div class="alert alert-success"><i class="fa-solid fa-check" style="margin-right:0.5rem;"></i>设置已保存</div>
{{end}}
{{if eq .Err "password"}}
<div class="alert alert-error"><i class="fa-solid fa-xmark" style="margin-right:0.5rem;"></i>旧密码错误</div>
{{end}}

<div class="glass" style="padding:1.5rem;margin-bottom:1.5rem;">
  <h3 style="font-size:1rem;font-weight:600;color:var(--text);margin-bottom:1rem;"><i class="fa-solid fa-key" style="color:#f59e0b;margin-right:0.5rem;"></i>修改密码</h3>
  <form action="/setting/save" method="post" style="display:grid;gap:0.75rem;">
    <input type="password" name="old" placeholder="当前密码" class="input">
    <input type="password" name="new" placeholder="新密码（留空不修改）" class="input">
    <button class="btn btn-primary" style="width:100%;"><i class="fa-solid fa-save"></i>保存密码</button>
  </form>
</div>

<div class="glass" style="padding:1.5rem;">
  <h3 style="font-size:1rem;font-weight:600;color:var(--text);margin-bottom:1rem;"><i class="fa-solid fa-image" style="color:#f59e0b;margin-right:0.5rem;"></i>背景设置</h3>
  <form action="/setting/save" method="post" style="display:grid;gap:0.75rem;">
    <div class="radio-group">
      <label class="radio-label"><input type="radio" name="bg_type" value="gradient"{{if eq .BgType "gradient"}} checked{{end}}>渐变背景</label>
      <label class="radio-label"><input type="radio" name="bg_type" value="image"{{if eq .BgType "image"}} checked{{end}}>图片背景</label>
    </div>
    <input type="url" name="bg_url" placeholder="图片 API 地址，如 https://api.btstu.cn/sjbz/api.php" value="{{.BgUrl}}" class="input">
    <button class="btn btn-primary" style="width:100%;"><i class="fa-solid fa-save"></i>保存背景</button>
  </form>
</div>
</div>
<script>
(function(){var b=document.getElementById('themeBtn');if(!b)return;var s=localStorage.getItem('lp_theme');if(s==='light'){document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';}b.addEventListener('click',function(){var c=document.documentElement.getAttribute('data-theme');if(c==='light'){document.documentElement.removeAttribute('data-theme');b.innerHTML='<i class="fa-solid fa-moon"></i>';localStorage.setItem('lp_theme','dark');}else{document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';localStorage.setItem('lp_theme','light');}});})();
</script>
</body>
</html>`

const htmlSystem = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="5">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>系统监控 - LightPanel</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
:root { --accent:#3b82f6; --bg:#0f0f23; --bg-card:rgba(255,255,255,0.03); --bg-glass:rgba(255,255,255,0.05); --text:#fff; --text-dim:rgba(255,255,255,0.4); --border:rgba(255,255,255,0.08); }
[data-theme="light"] { --bg:#f0f2f5; --bg-card:#fff; --bg-glass:rgba(0,0,0,0.03); --text:#1a1a2e; --text-dim:rgba(0,0,0,0.4); --border:rgba(0,0,0,0.08); }
* { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',system-ui,sans-serif; }
body { background:var(--bg); min-height:100vh; position:relative; }
.bg-layer { position:fixed; inset:0; z-index:0; background:radial-gradient(ellipse at 50% 50%,rgba(59,130,246,0.1) 0%,transparent 60%),var(--bg); }
.container { position:relative; z-index:1; max-width:1000px; margin:0 auto; padding:1.5rem; }
.glass { background:var(--bg-card); backdrop-filter:blur(20px) saturate(180%); border:1px solid var(--border); border-radius:16px; overflow:hidden; }
.btn { display:inline-flex; align-items:center; justify-content:center; gap:0.5rem; padding:0.6rem 1.2rem; border-radius:12px; font-size:0.875rem; font-weight:500; transition:all 0.2s ease; cursor:pointer; border:none; text-decoration:none; }
.btn-ghost { background:var(--bg-glass); color:var(--text); border:1px solid var(--border); backdrop-filter:blur(12px); }
.btn-ghost:hover { background:var(--border); color:var(--text); }
table { width:100%; border-collapse:collapse; }
th { padding:0.85rem 1rem; text-align:left; font-size:0.7rem; text-transform:uppercase; letter-spacing:1px; color:var(--text-dim); border-bottom:1px solid var(--border); }
td { padding:0.7rem 1rem; font-size:0.85rem; color:var(--text-dim); border-bottom:1px solid var(--border); font-family:'JetBrains Mono',monospace; }
tr:hover td { background:var(--bg-glass); }
.pid { color:#60a5fa; }
.kill { color:#f87171; background:none; border:none; padding:0; cursor:pointer; opacity:0.6; transition:opacity 0.2s; }
.kill:hover { opacity:1; }
</style>
</head>
<body>
<div class="bg-layer"></div>
<div class="container">
<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem;">
  <a href="/" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i>返回</a>
  <h1 style="font-size:1.5rem;font-weight:700;color:var(--text);margin-left:auto;"><i class="fa-solid fa-chart-line" style="color:#3b82f6;margin-right:0.5rem;"></i>系统进程 <span style="font-size:0.8rem;color:var(--text-dim);font-weight:400;">自动刷新 5s</span></h1>
  <button id="themeBtn" class="btn btn-ghost" title="切换主题"><i class="fa-solid fa-moon"></i></button>
  <a href="/logout" class="btn btn-ghost" style="color:#f87171;" title="退出"><i class="fa-solid fa-right-from-bracket"></i></a>
</div>
<div class="glass" style="overflow-x:auto;">
<table>
<tr><th>PID</th><th>CPU%</th><th>MEM%</th><th>进程名</th><th>操作</th></tr>
{{range .}}
<tr>
<td class="pid">{{.PID}}</td>
<td>{{formatFloat .Cpu}}</td>
<td>{{formatFloat .Mem}}</td>
<td style="font-family:'Inter',sans-serif;">{{.Name}}</td>
<td><form action="/kill/{{.PID}}" method="post" style="display:inline;"><button class="kill" onclick="return confirm('结束进程 {{.PID}}？')" style="background:none;border:none;padding:0;cursor:pointer;" type="submit"><i class="fa-solid fa-xmark"></i></button></form></td>
</tr>
{{end}}
</table>
</div>
</div>
<script>
(function(){var b=document.getElementById('themeBtn');if(!b)return;var s=localStorage.getItem('lp_theme');if(s==='light'){document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';}b.addEventListener('click',function(){var c=document.documentElement.getAttribute('data-theme');if(c==='light'){document.documentElement.removeAttribute('data-theme');b.innerHTML='<i class="fa-solid fa-moon"></i>';localStorage.setItem('lp_theme','dark');}else{document.documentElement.setAttribute('data-theme','light');b.innerHTML='<i class="fa-solid fa-sun"></i>';localStorage.setItem('lp_theme','light');}});})();
</script>
</body>
</html>`

const htmlLog = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>日志 - LightPanel</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
:root { --accent:#6366f1; --bg:#0f0f23; --bg-card:rgba(255,255,255,0.03); --bg-glass:rgba(255,255,255,0.05); --text:#fff; --text-dim:rgba(255,255,255,0.4); --border:rgba(255,255,255,0.08); }
[data-theme="light"] { --bg:#f0f2f5; --bg-card:#fff; --bg-glass:rgba(0,0,0,0.03); --text:#1a1a2e; --text-dim:rgba(0,0,0,0.4); --border:rgba(0,0,0,0.08); }
* { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',system-ui,sans-serif; }
body { background:var(--bg); min-height:100vh; position:relative; }
.bg-layer { position:fixed; inset:0; z-index:0; background:radial-gradient(ellipse at 60% 40%,rgba(99,102,241,0.1) 0%,transparent 60%),var(--bg); }
.container { position:relative; z-index:1; max-width:900px; margin:0 auto; padding:1.5rem; }
.btn { display:inline-flex; align-items:center; justify-content:center; gap:0.5rem; padding:0.6rem 1.2rem; border-radius:12px; font-size:0.875rem; font-weight:500; transition:all 0.2s ease; cursor:pointer; border:none; text-decoration:none; }
.btn-ghost { background:var(--bg-glass); color:var(--text); border:1px solid var(--border); backdrop-filter:blur(12px); }
.btn-ghost:hover { background:var(--border); color:var(--text); }
.btn-danger { background:linear-gradient(135deg,#ef4444,#dc2626); color:#fff; }
.btn-sm { padding:0.4rem 0.8rem; font-size:0.75rem; border-radius:8px; }
.btn-active { background:rgba(99,102,241,0.2); color:#a5b4fc; border-color:rgba(99,102,241,0.4); }
.log-box { background:rgba(0,0,0,0.4); border:1px solid var(--border); border-radius:12px; padding:1rem; height:75vh; overflow-y:auto; font-family:'JetBrains Mono',monospace; font-size:0.78rem; line-height:1.7; color:var(--text-dim); white-space:pre-wrap; word-break:break-all; }
.log-box::-webkit-scrollbar { width:6px; }
.log-box::-webkit-scrollbar-track { background:transparent; }
.log-box::-webkit-scrollbar-thumb { background:rgba(255,255,255,0.1); border-radius:3px; }
.log-error { color:#f87171; }
.log-warn { color:#fbbf24; }
.log-info { color:#60a5fa; }
.filter-bar { display:flex; gap:0.5rem; margin-bottom:1rem; flex-wrap:wrap; align-items:center; }
</style>
</head>
<body>
<div class="bg-layer"></div>
<div class="container">
<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem;">
  <a href="/" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i>返回</a>
  <h1 style="font-size:1.2rem;font-weight:600;color:var(--text);margin-left:auto;"><i class="fa-solid fa-file-lines" style="color:#6366f1;margin-right:0.5rem;"></i>{{.Name}} 运行日志</h1>
  <form action="/log/clear/{{.Name}}" method="post" style="display:inline;"><button class="btn btn-danger btn-sm" onclick="return confirm('清空日志？')"><i class="fa-solid fa-trash"></i>清空</button></form>
  <button id="themeBtn" class="btn btn-ghost" title="切换主题"><i class="fa-solid fa-moon"></i></button>
  <a href="/logout" class="btn btn-ghost" style="color:#f87171;" title="退出"><i class="fa-solid fa-right-from-bracket"></i></a>
</div>

<div class="filter-bar">
  <button class="btn btn-ghost btn-sm log-filter btn-active" data-filter="all"><i class="fa-solid fa-list"></i> 全部</button>
  <button class="btn btn-ghost btn-sm log-filter" data-filter="error"><i class="fa-solid fa-circle-xmark" style="color:#f87171;"></i> 错误</button>
  <button class="btn btn-ghost btn-sm log-filter" data-filter="warn"><i class="fa-solid fa-triangle-exclamation" style="color:#fbbf24;"></i> 警告</button>
  <button class="btn btn-ghost btn-sm log-filter" data-filter="info"><i class="fa-solid fa-circle-info" style="color:#60a5fa;"></i> 信息</button>
  <button class="btn btn-ghost btn-sm log-filter" data-filter="crash"><i class="fa-solid fa-skull" style="color:#ef4444;"></i> 崩溃</button>
  <span style="margin-left:auto;font-size:0.75rem;color:var(--text-dim);" id="logCount">{{.LineCount}} 行</span>
</div>

<pre class="log-box" id="logBox">{{.Log}}</pre>
</div>

<script>
var logBox = document.getElementById('logBox');
logBox.scrollTop = logBox.scrollHeight;
var originalLogText = logBox.textContent;

var filters = {
  all: null,
  error: [/error/i, /fail/i, /fatal/i, /panic/i, /exception/i, /crash/i, /cannot/i, /not found/i, /no such/i, /refused/i, /denied/i, /missing/i],
  warn: [/warn/i, /deprecated/i, /timeout/i, /retry/i, /slow/i],
  info: [/info/i, /start/i, /stop/i, /listen/i, /ready/i, /connect/i],
  crash: [/panic/i, /fatal/i, /segfault/i, /core dump/i, /killed/i, /oom/i, /out of memory/i]
};

document.querySelectorAll('.log-filter').forEach(function(btn) {
  btn.addEventListener('click', function(e) {
    e.preventDefault();
    var f = this.dataset.filter;
    document.querySelectorAll('.log-filter').forEach(function(b) { b.classList.remove('btn-active'); });
    this.classList.add('btn-active');

    var lines = originalLogText.split('\n');
    var pat = filters[f];
    if (!pat) {
      logBox.textContent = originalLogText;
    } else {
      var matched = [];
      for (var i = 0; i < lines.length; i++) {
        for (var j = 0; j < pat.length; j++) {
          if (pat[j].test(lines[i])) { matched.push(lines[i]); break; }
        }
      }
      logBox.textContent = matched.join('\n');
    }
    document.getElementById('logCount').textContent = (f === 'all' ? originalLogText.split('\n').length : (logBox.textContent ? logBox.textContent.split('\n').length : 0)) + ' 行';
  });
});
</script>
</body>
</html>`
