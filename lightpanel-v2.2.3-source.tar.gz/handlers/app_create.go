package handlers

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"lightpanel/config"
	"lightpanel/models"
)

var createTasks sync.Map

type CreateTask struct {
	ID        string
	Name      string
	Progress  int
	Status    string
	Message   string
	CreatedAt time.Time
}

func apiCreateProgress(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	taskID := strings.TrimPrefix(r.URL.Path, "/create/progress/")
	val, ok := createTasks.Load(taskID)
	if !ok {
		json.NewEncoder(w).Encode(map[string]any{"status": "not_found"})
		return
	}
	task := val.(*CreateTask)
	json.NewEncoder(w).Encode(task)
}

func createApp(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")

	_ = r.ParseForm()
	name := strings.TrimSpace(r.Form.Get("name"))
	down := strings.TrimSpace(r.Form.Get("url"))
	cmd := strings.TrimSpace(r.Form.Get("cmd"))
	setupCmd := strings.TrimSpace(r.Form.Get("setup_cmd"))

	if name == "" {
		json.NewEncoder(w).Encode(map[string]any{
			"error":    "应用名称不能为空",
			"debug":    map[string]string{"form_name": r.Form.Get("name"), "form_cmd": r.Form.Get("cmd"), "content_type": r.Header.Get("Content-Type")},
		})
		return
	}
	if cmd == "" {
		json.NewEncoder(w).Encode(map[string]any{"error": "启动命令不能为空"})
		return
	}
	if strings.ContainsAny(name, `/\`) || strings.ContainsAny(name, `;&|'`) || strings.HasPrefix(name, ".") || strings.Contains(name, "..") {
		json.NewEncoder(w).Encode(map[string]any{"error": "应用名称包含非法字符，仅允许字母数字"})
		return
	}

	appOpMu.Lock()
	var apps map[string]models.Project
	_ = LoadJSON(config.ConfigApps, &apps)
	if _, exists := apps[name]; exists {
		appOpMu.Unlock()
		json.NewEncoder(w).Encode(map[string]any{"error": "应用已存在"})
		return
	}
	appOpMu.Unlock()

	taskID := "create_" + strconv.FormatInt(time.Now().UnixNano(), 36)
	task := &CreateTask{
		ID:        taskID,
		Name:      name,
		Progress:  0,
		Status:    "creating",
		Message:   "准备创建...",
		CreatedAt: time.Now(),
	}
	createTasks.Store(taskID, task)

	go func() {
		sandbox := filepath.Join(config.AppsDir, name)
		if err := os.MkdirAll(sandbox, 0755); err != nil {
			task.Status = "error"
			task.Message = "创建目录失败"
			return
		}

		if down != "" {
			if !strings.HasPrefix(down, "http://") && !strings.HasPrefix(down, "https://") {
				task.Status = "error"
				task.Message = "URL 格式错误"
				_ = os.RemoveAll(sandbox)
				return
			}

			dlID := "dl_" + strconv.FormatInt(time.Now().UnixNano(), 36)
			dlTask := &models.DownloadTask{
				ID:     dlID,
				Name:   name,
				URL:    down,
				Cmd:    cmd,
				Status: "downloading",
				Last:   time.Now(),
			}
			downloadTasks.Store(dlID, dlTask)
			task.Message = "正在下载..."
			task.Progress = 10

			client := &http.Client{Timeout: 120 * time.Second}
			resp, e := client.Get(down)
			if e != nil {
				dlTask.SetStatus("error")
				dlTask.Last = time.Now()
				task.Status = "error"
				task.Message = "下载失败: " + e.Error()
				_ = os.RemoveAll(sandbox)
				return
			}
			defer resp.Body.Close()
			if resp.StatusCode != 200 {
				dlTask.SetStatus("error")
				dlTask.Last = time.Now()
				task.Status = "error"
				task.Message = "HTTP " + fmt.Sprint(resp.StatusCode)
				_ = os.RemoveAll(sandbox)
				return
			}

			dlTask.Size = resp.ContentLength
			fname := filepath.Base(down)
			if fname == "" || fname == "." || fname == "/" {
				fname = "download"
			}
			fpath := filepath.Join(sandbox, fname)
			f, err := os.Create(fpath)
			if err != nil {
				dlTask.SetStatus("error")
				dlTask.Last = time.Now()
				task.Status = "error"
				task.Message = "创建文件失败"
				_ = os.RemoveAll(sandbox)
				return
			}

			buf := make([]byte, 32*1024)
			var totalWritten int64
			for {
				n, readErr := resp.Body.Read(buf)
				if n > 0 {
					if _, writeErr := f.Write(buf[:n]); writeErr != nil {
						_ = f.Close()
						dlTask.SetStatus("error")
						dlTask.Last = time.Now()
						task.Status = "error"
						task.Message = "写入失败"
						_ = os.Remove(fpath)
						_ = os.RemoveAll(sandbox)
						return
					}
					totalWritten += int64(n)
					if dlTask.Size > 0 {
						dlTask.Downloaded = totalWritten
						dlTask.Progress = int(float64(totalWritten) / float64(dlTask.Size) * 90)
						task.Progress = 10 + dlTask.Progress/10
					}
				}
				if readErr != nil {
					if !errors.Is(readErr, io.EOF) {
						_ = f.Close()
						dlTask.SetStatus("error")
						dlTask.Last = time.Now()
						task.Status = "error"
						task.Message = "读取失败"
						_ = os.Remove(fpath)
						_ = os.RemoveAll(sandbox)
						return
					}
					break
				}
				if totalWritten >= config.MaxDownBytes {
					break
				}
			}
			_ = f.Close()

			dlTask.SetStatus("completed")
			dlTask.Progress = 100
			dlTask.Last = time.Now()
			task.Progress = 50
			task.Message = "正在解压..."

			if extractArchive(fpath, sandbox) {
				_ = os.Remove(fpath)
			} else if strings.HasSuffix(fname, ".sh") {
				_ = os.Chmod(fpath, 0755)
			}
		}

		task.Progress = 80
		task.Message = "保存配置..."

		appOpMu.Lock()
		var finalApps map[string]models.Project
		_ = LoadJSON(config.ConfigApps, &finalApps)
		finalApps[name] = models.Project{
			Path:      sandbox,
			Cmd:       cmd,
			SetupCmd:  setupCmd,
			WorkDir:   "",
			SourceURL: down,
			Created:   time.Now().Format("2006-01-02 15:04"),
		}
		_ = WriteJSON(config.ConfigApps, finalApps)
		appOpMu.Unlock()

		task.Progress = 100
		task.Status = "completed"
		task.Message = "创建完成"

		if down != "" && (strings.HasSuffix(strings.ToLower(down), ".sh") || strings.Contains(strings.ToLower(down), "install")) {
			go func() {
				time.Sleep(15 * time.Second)
				scanTime := time.Now().Add(-20 * time.Second)
				result := combinedDetect(sandbox, scanTime)
				appOpMu.Lock()
				var updated map[string]models.Project
				if err := LoadJSON(config.ConfigApps, &updated); err == nil {
					if proj, ok := updated[name]; ok {
						if result.WorkDir != "" {
							proj.WorkDir = result.WorkDir
						}
						if result.Binary != "" {
							proj.Cmd = result.Binary
						}
						updated[name] = proj
						_ = WriteJSON(config.ConfigApps, updated)
					}
				}
				appOpMu.Unlock()
				_ = os.WriteFile(filepath.Join(sandbox, "install_note.txt"), []byte(result.Note), 0644)
			}()
		}

		go func() {
			time.Sleep(5 * time.Minute)
			createTasks.Delete(taskID)
		}()
	}()

	json.NewEncoder(w).Encode(map[string]any{
		"ok":       true,
		"task":     taskID,
		"redirect": "/",
	})
}
